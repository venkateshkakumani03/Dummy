// CRUD Operations on HashMap
import java.io.*;
import java.util.*;

public class HashMapCRUD {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Map<String,String> map = new HashMap<>();
        while (true) {
            System.out.println("\n1: Create/Update 2: Read 3: Delete 4: List All 5: Exit");
            System.out.print("Choose: ");
            String choice = br.readLine();
            switch (choice) {
                case "1":
                    System.out.print("Key: "); String k = br.readLine();
                    System.out.print("Value: "); String v = br.readLine();
                    map.put(k, v);
                    System.out.println("Stored.");
                    break;
                case "2":
                    System.out.print("Key to read: ");
                    String rk = br.readLine();
                    System.out.println("Value: " + map.getOrDefault(rk,"<not found>"));
                    break;
                case "3":
                    System.out.print("Key to delete: ");
                    String dk = br.readLine();
                    map.remove(dk);
                    System.out.println("Deleted.");
                    break;
                case "4":
                    System.out.println("All entries:");
                    map.forEach((key,val) -> System.out.println(key + " => " + val));
                    break;
                case "5":
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
