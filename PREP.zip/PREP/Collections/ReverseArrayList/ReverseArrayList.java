import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The {@code ReverseArrayList} class demonstrates how to reverse the order of elements
 * in an {@link ArrayList} using {@link Collections#reverse(List)}.
 * <p>
 * It reads integers from the user, stores them in a list, and prints the reversed list.
 * </p>
 * 
 * @author Venkatesh Kakumani
 * @version 1.0
 * @since 2025-06-16
 */
public class ReverseArrayList {

    /**
     * The main method is the entry point of the program.
     * It reads integers from the user, reverses the list, and prints the result.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        List<Integer> list = readIntegersFromUser();
        reverseList(list);
        printList(list);
    }

    /**
     * Reads a list of integers from the user using {@link BufferedReader}.
     * Handles exceptions internally and returns an empty list if an error occurs.
     *
     * @return a list of integers entered by the user
     */
    private static List<Integer> readIntegersFromUser() {
        List<Integer> list = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter the number of elements: ");
            int size = Integer.parseInt(reader.readLine().trim());

            if (size <= 0) {
                System.err.println("Invalid input: The number of elements must be greater than zero.");
                return list;
            }

            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                String input = reader.readLine().trim();
                int number = Integer.parseInt(input);
                list.add(number);
            }

        } catch (IOException e) {
            System.err.println("Input error: Unable to read from the console.");
        } catch (NumberFormatException e) {
            System.err.println("Format error: Please enter valid integers only.");
        }

        return list;
    }

    /**
     * Reverses the order of elements in the given list.
     *
     * @param list the list to reverse
     */
    private static void reverseList(List<Integer> list) {
        Collections.reverse(list);
    }

    /**
     * Prints the contents of the list to the console.
     *
     * @param list the list of integers to print
     */
    private static void printList(List<Integer> list) {
        if (list.isEmpty()) {
            System.out.println("No elements to display.");
        } else {
            System.out.println("Reversed ArrayList: " + list);
        }
    }
}
