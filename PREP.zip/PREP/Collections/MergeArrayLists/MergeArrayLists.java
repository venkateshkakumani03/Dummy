import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * The {@code MergeArrayLists} class demonstrates how to merge two {@link ArrayList}s
 * of strings entered by the user.
 * <p>
 * It uses {@link BufferedReader} for input and {@link List#addAll(List)} to merge lists.
 * </p>
 * 
 * @author Venkatesh Kakumani
 * @version 1.0
 * @since 2025-06-16
 */
public class MergeArrayLists {

    /**
     * The main method is the entry point of the program.
     * It reads two lists from the user, merges them, and prints the result.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        List<String> list1 = readListFromUser("first");
        List<String> list2 = readListFromUser("second");

        List<String> mergedList = mergeLists(list1, list2);
        printList(mergedList);
    }

    /**
     * Reads a list of strings from the user using {@link BufferedReader}.
     *
     * @param label a label to identify which list is being read
     * @return a list of strings entered by the user
     */
    private static List<String> readListFromUser(String label) {
        List<String> list = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter the number of elements in the " + label + " list: ");
            int size = Integer.parseInt(reader.readLine().trim());

            if (size <= 0) {
                System.err.println("Invalid input: The number of elements must be greater than zero.");
                return list;
            }

            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + " of the " + label + " list: ");
                String input = reader.readLine().trim();
                if (input.isEmpty()) {
                    System.err.println("Invalid input: Element cannot be empty.");
                    continue;
                }
                list.add(input);
            }

        } catch (IOException e) {
            System.err.println("Input error: Unable to read from the console.");
        } catch (NumberFormatException e) {
            System.err.println("Format error: Please enter a valid integer for the number of elements.");
        }

        return list;
    }

    /**
     * Merges two lists into a single list.
     *
     * @param list1 the first list
     * @param list2 the second list
     * @return a new list containing all elements from both input lists
     */
    private static List<String> mergeLists(List<String> list1, List<String> list2) {
        List<String> merged = new ArrayList<>(list1);
        merged.addAll(list2);
        return merged;
    }

    /**
     * Prints the contents of the list to the console.
     *
     * @param list the list of strings to print
     */
    private static void printList(List<String> list) {
        if (list.isEmpty()) {
            System.out.println("No elements to display.");
        } else {
            System.out.println("Merged ArrayList: " + list);
        }
    }
}
