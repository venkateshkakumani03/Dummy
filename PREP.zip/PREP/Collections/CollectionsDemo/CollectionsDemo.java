import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import java.util.Enumeration;
// import java.util.*;

public class CollectionsDemo {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        // Input section
        System.out.print("Enter number of elements: ");
        int n = Integer.parseInt(br.readLine().trim());

        List<Integer> original = new ArrayList<>();
        System.out.println("Enter " + n + " integers (one per line):");
        for (int i = 0; i < n; i++) {
            original.add(Integer.parseInt(br.readLine().trim()));
        }

        System.out.println("\n===== Original List =====");
        System.out.println(original);

        System.out.println("\n===== java.util.Collections Methods Demo =====");

        // 1. sort(List)
        List<Integer> sortedList = new ArrayList<>(original);
        System.out.println("\n1. sort(List): Sorts the list in natural ascending order.");
        Collections.sort(sortedList);
        System.out.println("Sorted List: " + sortedList);

        // 2. sort(List, Comparator)
        List<Integer> descList = new ArrayList<>(original);
        System.out.println("\n2. sort(List, Comparator): Sorts the list using a custom comparator (descending here).");
        Collections.sort(descList, Collections.reverseOrder());
        System.out.println("Sorted in Descending: " + descList);

        // 3. binarySearch
        System.out.println("\n3. binarySearch(List, key): Searches for a key in sorted list using binary search.");
        if (!sortedList.isEmpty()) {
            // int key = sortedList.get(0);
			int key = Integer.parseInt(br.readLine().trim());
            int index = Collections.binarySearch(sortedList, key);
            System.out.println("Key: " + key + " found at index: " + index);
        }

        // 4. reverse
        List<Integer> reversed = new ArrayList<>(original);
        System.out.println("\n4. reverse(List): Reverses the order of elements.");
        Collections.reverse(reversed);
        System.out.println("Reversed List: " + reversed);

        // 5. shuffle
        List<Integer> shuffled = new ArrayList<>(original);
        System.out.println("\n5. shuffle(List): Randomly shuffles the list.");
        Collections.shuffle(shuffled);
        System.out.println("Shuffled List: " + shuffled);

        // 6. rotate
        List<Integer> rotated = new ArrayList<>(original);
        System.out.println("\n6. rotate(List, distance): Rotates elements by given distance.");
        Collections.rotate(rotated, 2);
        System.out.println("Rotated by 2: " + rotated);

        // 7. swap
        List<Integer> swapped = new ArrayList<>(original);
        System.out.println("\n7. swap(List, i, j): Swaps elements at two positions.");
        if (swapped.size() >= 2) {
            Collections.swap(swapped, 0, 1);
            System.out.println("Swapped 0 and 1: " + swapped);
        } else {
            System.out.println("Not enough elements to swap.");
        }

        // 8. fill
        List<Integer> filled = new ArrayList<>(Collections.nCopies(n, 0));
        System.out.println("\n8. fill(List, value): Replaces all elements with specified value.");
		//Collections.fill(filled, 999);
		int specifiedValue = Integer.parseInt(br.readLine().trim());
        Collections.fill(filled, specifiedValue);
        System.out.println("Filled List: " + filled);

        // 9. copy
        System.out.println("\n9. copy(dest, src): Copies all elements from source to destination list.");
        List<Integer> dest = new ArrayList<>(Collections.nCopies(n, 0));
        Collections.copy(dest, original);
        System.out.println("Destination after copy: " + dest);

        // 10. max/min
        System.out.println("\n10. max(List) / min(List): Returns the max and min element.");
        System.out.println("Max: " + Collections.max(original));
        System.out.println("Min: " + Collections.min(original));

        // 11. max/min with comparator
        System.out.println("\n11. max/min(List, Comparator): Uses comparator to get max/min (reverse).");
        System.out.println("Max (reverse order): " + Collections.max(original, Collections.reverseOrder()));
        System.out.println("Min (reverse order): " + Collections.min(original, Collections.reverseOrder()));

        // 12. frequency
        System.out.println("\n12. frequency(Collection, element): Counts how many times an element occurs.");
        if (!original.isEmpty()) {
            // int val = original.get(0);
			int val = Integer.parseInt(br.readLine().trim());
            int freq = Collections.frequency(original, val);
            System.out.println("Frequency of " + val + ": " + freq);
        }

        // 13. indexOfSubList / lastIndexOfSubList
        System.out.println("\n13. indexOfSubList / lastIndexOfSubList: Finds position of sublist.");
        List<Integer> subList = original.subList(0, Math.min(2, original.size()));
        System.out.println("SubList: " + subList);
        System.out.println("First index: " + Collections.indexOfSubList(original, subList));
        System.out.println("Last index: " + Collections.lastIndexOfSubList(original, subList));

        // 14. disjoint
        System.out.println("\n14. disjoint(Collection1, Collection2): Checks if two collections share no elements.");
        List<Integer> other = Arrays.asList(-100, -200);
        System.out.println("Other List: " + other);
        System.out.println("Disjoint with original? " + Collections.disjoint(original, other));

        // 15. replaceAll
        List<Integer> replaced = new ArrayList<>(original);
        System.out.println("\n15. replaceAll(List, oldVal, newVal): Replaces all occurrences of oldVal with newVal.");
        if (!original.isEmpty()) {
            Collections.replaceAll(replaced, original.get(0), 111);
            System.out.println("After replaceAll: " + replaced);
        }

        // 16. nCopies
        System.out.println("\n16. nCopies(n, val): Returns an immutable list of n copies of the value.");
        List<String> repeated = Collections.nCopies(3, "Hello");
        System.out.println("Repeated List: " + repeated);

        // 17. singleton / singletonList
        System.out.println("\n17. singletonList(val): Immutable list with one element.");
        System.out.println("Singleton List: " + Collections.singletonList(999));
        System.out.println("Singleton Set: " + Collections.singleton("One"));

        // 18. emptyList / emptySet / emptyMap
        System.out.println("\n18. emptyList / emptySet / emptyMap: Returns immutable empty collections.");
        System.out.println("Empty List: " + Collections.emptyList());
        System.out.println("Empty Set: " + Collections.emptySet());
        System.out.println("Empty Map: " + Collections.emptyMap());

        // 19. unmodifiable collections
        List<Integer> unmod = Collections.unmodifiableList(new ArrayList<>(original));
        System.out.println("\n19. unmodifiableList(): Read-only version of the list.");
        System.out.println("Unmodifiable List: " + unmod);
        // unmod.add(10); // Uncommenting will throw UnsupportedOperationException

        // 20. synchronizedList
        List<Integer> syncList = Collections.synchronizedList(new ArrayList<>(original));
        System.out.println("\n20. synchronizedList(): Thread-safe version of the list.");
        System.out.println("Synchronized List: " + syncList);

        // 21. reverseOrder Comparator
        System.out.println("\n21. reverseOrder(): Returns a comparator that reverses natural ordering.");
        List<Integer> reverseOrderList = new ArrayList<>(original);
        reverseOrderList.sort(Collections.reverseOrder());
        System.out.println("Sorted using reverseOrder(): " + reverseOrderList);

        // 22. enumeration + list
        System.out.println("\n22. list(Enumeration): Converts Enumeration to List.");
        Vector<Integer> vector = new Vector<>(original);
        Enumeration<Integer> enumeration = vector.elements();
        List<Integer> fromEnum = Collections.list(enumeration);
        System.out.println("Converted from Enumeration: " + fromEnum);

        System.out.println("\n===== End of Demo =====");
    }
}
