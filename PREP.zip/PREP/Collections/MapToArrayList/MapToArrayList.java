import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class MapToArrayList {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Map<Integer, String> map = new HashMap<>();

        System.out.print("How many entries do you want to add? ");
        int count = Integer.parseInt(reader.readLine());

        for (int i = 0; i < count; i++) {
            System.out.print("Enter key (Integer): ");
            int key = Integer.parseInt(reader.readLine());

            System.out.print("Enter value (String): ");
            String value = reader.readLine();

            map.put(key, value);
        }

        // Convert map values to ArrayList
        List<String> list = new ArrayList<>(map.values());

        System.out.println("\nArrayList of values:");
        for (String val : list) {
            System.out.println(val);
        }

        // Find and print duplicates
        Set<String> seen = new HashSet<>();
        Set<String> duplicates = new HashSet<>();

        for (String val : list) {
            if (!seen.add(val)) {
                duplicates.add(val);
            }
        }

        System.out.println("\nDuplicate values:");
        if (duplicates.isEmpty()) {
            System.out.println("No duplicates found.");
        } else {
            for (String dup : duplicates) {
                System.out.println(dup);
            }
        }
    }
}
