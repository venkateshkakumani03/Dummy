import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * The {@code CustomSortArrayList} class demonstrates how to sort an {@link ArrayList}
 * of strings based on custom criteria—in this case, the length of each string.
 * <p>
 * It uses {@link BufferedReader} for user input and {@link Comparator} for custom sorting.
 * </p>
 * 
 * @author Venkatesh Kakumani
 * @version 1.0
 * @since 2025-06-16
 */
public class CustomSortArrayList {

    /**
     * The main method is the entry point of the program.
     * It reads strings from the user, sorts them by length, and prints the result.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        List<String> list = readStringsFromUser();
        sortByLength(list);
        printList(list);
    }

    /**
     * Reads a list of strings from the user using {@link BufferedReader}.
     * Handles exceptions internally and returns an empty list if an error occurs.
     *
     * @return a list of strings entered by the user
     */
    private static List<String> readStringsFromUser() {
        List<String> list = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter the number of elements: ");
            int size = Integer.parseInt(reader.readLine().trim());

            if (size <= 0) {
                System.err.println("Invalid input: The number of elements must be greater than zero.");
                return list;
            }

            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                String input = reader.readLine().trim();
                if (input.isEmpty()) {
                    System.err.println("Invalid input: Element cannot be empty.");
                    continue;
                }
                list.add(input);
            }

        } catch (IOException e) {
            System.err.println("Input error: Unable to read from the console.");
        } catch (NumberFormatException e) {
            System.err.println("Format error: Please enter a valid integer for the number of elements.");
        }

        return list;
    }

    /**
     * Sorts the list of strings by their length using a custom {@link Comparator}.
     *
     * @param list the list of strings to sort
     */
    private static void sortByLength(List<String> list) {
        list.sort(Comparator.comparingInt(String::length));
    }

    /**
     * Prints the contents of the list to the console.
     *
     * @param list the list of strings to print
     */
    private static void printList(List<String> list) {
        if (list.isEmpty()) {
            System.out.println("No elements to display.");
        } else {
            System.out.println("Sorted by length: " + list);
        }
    }
}

//All in main method
/*
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CustomSortArrayList {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            List<String> list = new ArrayList<>();

            System.out.print("Enter the number of elements: ");
            int size = Integer.parseInt(reader.readLine().trim());

            if (size <= 0) {
                System.err.println("Invalid input: The number of elements must be greater than zero.");
                return;
            }

            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                String input = reader.readLine().trim();
                if (!input.isEmpty()) {
                    list.add(input);
                } else {
                    System.err.println("Invalid input: Element cannot be empty.");
                }
            }

            list.sort(Comparator.comparingInt(String::length));

            if (list.isEmpty()) {
                System.out.println("No elements to display.");
            } else {
                System.out.println("Sorted by length: " + list);
            }

        } catch (IOException e) {
            System.err.println("Input error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Format error: Please enter a valid integer.");
        }
    }
}*/