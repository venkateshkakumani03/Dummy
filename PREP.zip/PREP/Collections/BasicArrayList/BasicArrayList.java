import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * The {@code BasicArrayList} class demonstrates how to use an {@link ArrayList}
 * to store and display a list of strings entered by the user.
 * <p>
 * It uses {@link BufferedReader} for input and includes internal exception handling
 * and clean code practices.
 * </p>
 * 
 * @author Venkatesh Kakumani
 * @version 1.2
 */
public class BasicArrayList {

    /**
     * The main method is the entry point of the program.
     * It calls methods to read and print the list.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        List<String> list = readStringsFromUser();
        printList(list);
    }

    /**
     * Reads a list of strings from the user using {@link BufferedReader}.
     * Handles exceptions internally and returns an empty list if an error occurs.
     *
     * @return a list of strings entered by the user, or an empty list if an error occurs
     */
    private static List<String> readStringsFromUser() {
        List<String> list = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter the number of elements: ");
            String inputSize = reader.readLine();
            int size = Integer.parseInt(inputSize.trim());

            if (size <= 0) {
                System.err.println("Invalid input: The number of elements must be greater than zero.");
                return list;
            }

            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                String input = reader.readLine();
                if (input == null || input.trim().isEmpty()) {
                    System.err.println("Invalid input: Element cannot be empty.");
                    continue;
                }
                list.add(input.trim());
            }

        } catch (IOException e) {
            System.err.println("Input error: Unable to read from the console. Please check your input device.");
        } catch (NumberFormatException e) {
            System.err.println("Format error: Please enter a valid whole number for the number of elements.");
        }

        return list;
    }

    /**
     * Prints the contents of the list to the console.
     *
     * @param list the list of strings to print
     */
    private static void printList(List<String> list) {
        if (list.isEmpty()) {
            System.out.println("No elements to display.");
        } else {
            System.out.println("ArrayList elements: " + list);
        }
    }
}


//All in main methd
/*
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BasicArrayList {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            List<String> list = new ArrayList<>();

            System.out.print("Enter the number of elements: ");
            int size = Integer.parseInt(reader.readLine().trim());

            if (size <= 0) {
                System.err.println("Invalid input: The number of elements must be greater than zero.");
                return;
            }

            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                String input = reader.readLine();
                if (input == null || input.trim().isEmpty()) {
                    System.err.println("Invalid input: Element cannot be empty.");
                    continue;
                }
                list.add(input.trim());
            }

            if (list.isEmpty()) {
                System.out.println("No elements to display.");
            } else {
                System.out.println("ArrayList elements: " + list);
            }

        } catch (IOException e) {
            System.err.println("Input error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Format error: Please enter a valid number.");
        }
    }
}
*/