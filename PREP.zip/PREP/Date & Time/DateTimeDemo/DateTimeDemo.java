import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateTimeDemo {

    public static void main(String[] args) {
        // Current Date and Time
        LocalDate currentDate = LocalDate.now();
        LocalTime currentTime = LocalTime.now();
        LocalDateTime currentDateTime = LocalDateTime.now();
        ZonedDateTime currentZonedDateTime = ZonedDateTime.now();

        System.out.println("Current Date: " + currentDate);
        System.out.println("Current Time: " + currentTime);
        System.out.println("Current DateTime: " + currentDateTime);
        System.out.println(ZoneId.systemDefault());
        System.out.println("Current ZonedDateTime: " + currentZonedDateTime + "\n");

        // Formatting and Parsing
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        String formattedDate = currentDate.format(dateFormatter);
        String formattedTime = currentTime.format(timeFormatter);
        String formattedDateTime = currentDateTime.format(dateTimeFormatter);

        System.out.println("Formatted Date: " + formattedDate);
        System.out.println("Formatted Time: " + formattedTime);
        System.out.println("Formatted DateTime: " + formattedDateTime+ "\n");

        LocalDate parsedDate = LocalDate.parse("25-12-2023", dateFormatter);
        LocalTime parsedTime = LocalTime.parse("15:30:00", timeFormatter);
        LocalDateTime parsedDateTime = LocalDateTime.parse("25-12-2023 15:30:00", dateTimeFormatter);

        System.out.println("Parsed Date: " + parsedDate);
        System.out.println("Parsed Time: " + parsedTime);
        System.out.println("Parsed DateTime: " + parsedDateTime+ "\n");

        // Time Zone Conversion
        ZoneId zoneIdNY = ZoneId.of("America/New_York");
        ZoneId zoneIdLondon = ZoneId.of("Europe/London");

        ZonedDateTime nyDateTime = currentDateTime.atZone(zoneIdNY);
        ZonedDateTime londonDateTime = nyDateTime.withZoneSameInstant(zoneIdLondon);

        System.out.println("New York DateTime: " + nyDateTime);
        System.out.println("London DateTime: " + londonDateTime+ "\n");

        // Calculating Time Differences
        LocalDate startDate = LocalDate.of(2023, Month.JANUARY, 1);
        LocalDate endDate = LocalDate.of(2023, Month.DECEMBER, 31);

        Period period = Period.between(startDate, endDate);
        System.out.println("Period between " + startDate + " and " + endDate + ": " +
                period.getYears() + " years, " + period.getMonths() + " months, " + period.getDays() + " days"+ "\n");

        LocalTime startTime = LocalTime.of(9, 0);
        LocalTime endTime = LocalTime.of(17, 0);

        Duration duration = Duration.between(startTime, endTime);
        System.out.println("Duration between " + startTime + " and " + endTime + ": " +
                duration.toHours() + " hours, " + duration.toMinutes() + " minutes"+ "\n");

        // Adding and Subtracting Time
        LocalDate futureDate = currentDate.plusDays(10);
        LocalTime futureTime = currentTime.plusHours(5);
        LocalDateTime futureDateTime = currentDateTime.plusWeeks(2);

        System.out.println("Future Date (10 days later): " + futureDate);
        System.out.println("Future Time (5 hours later): " + futureTime);
        System.out.println("Future DateTime (2 weeks later): " + futureDateTime+ "\n");

        LocalDate pastDate = currentDate.minusMonths(3);
        LocalTime pastTime = currentTime.minusMinutes(30);
        LocalDateTime pastDateTime = currentDateTime.minusYears(1);

        System.out.println("Past Date (3 months earlier): " + pastDate);
        System.out.println("Past Time (30 minutes earlier): " + pastTime);
        System.out.println("Past DateTime (1 year earlier): " + pastDateTime);
    }
}
