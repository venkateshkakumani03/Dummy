import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * BoundaryTraversal - Prints the boundary elements of a matrix in clockwise order.
 *
 * @example
 * Input:
 * 3 4
 * 1 2 3 4
 * 5 6 7 8
 * 9 10 11 12
 * Output: [1,2,3,4,8,12,11,10,9,5]
 *
 * @author Venkatesh
 * @since 2025-07-11
 * @version 1.0
 */

public class BoundaryTraversal {
    public static void main(String[] args) {
        System.out.println("=== Boundary Traversal ===");
        try (BufferedReader br=new BufferedReader(new InputStreamReader(System.in))) {
            int[] d = readDims(br,"Enter rows and cols: ");
            int[][] m = readMatrix(br,d,"Enter matrix:");
            System.out.println(traverseBoundary(m));
        } catch(IOException|IllegalArgumentException e){
            System.err.println("Error: "+e.getMessage());
        }
    }

    private static List<Integer> traverseBoundary(int[][] m) {
        int r=m.length, c=m[0].length;
        List<Integer> res=new ArrayList<>();
        for(int j=0;j<c;j++) res.add(m[0][j]);
        for(int i=1;i<r;i++) res.add(m[i][c-1]);
        if(r>1) for(int j=c-2;j>=0;j--) res.add(m[r-1][j]);
        if(c>1) for(int i=r-2;i>=1;i--) res.add(m[i][0]);
        return res;
    }

    private static int[] readDims(BufferedReader br,String prompt) throws IOException{
        System.out.print(prompt);
		String[] p=br.readLine().trim().split("\\s+");
		if(p.length!=2)throw new IllegalArgumentException("Two ints expected.");
		return new int[]{Integer.parseInt(p[0]),Integer.parseInt(p[1])};
    }

    private static int[][] readMatrix(BufferedReader br,int[] d,String prompt) throws IOException{
        System.out.println(prompt);
		int r=d[0],c=d[1];
		int[][] m=new int[r][c];
		for(int i=0;i<r;i++){
			String[] row=br.readLine().trim().split("\\s+");
			if(row.length!=c)throw new IllegalArgumentException("Expected "+c+" vals.");
			for(int j=0;j<c;j++) m[i][j]=Integer.parseInt(row[j]);
		}
		return m;
    }
}
