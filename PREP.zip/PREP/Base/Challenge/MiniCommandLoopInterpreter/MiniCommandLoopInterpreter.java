import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

/**
 * Mini Command-Loop Interpreter (Optimal Version)
 *
 * Commands:
 *   add X Y   -> prints X + Y
 *   mul X Y   -> prints X * Y
 *   fact X    -> prints X! for X >= 0
 *   help      -> lists commands
 *   exit      -> quits
 *
 * Skips blank lines, catches all parse errors, and breaks on "exit".
 */
public class MiniCommandLoopInterpreter {

    public static void main(String[] args) {
        BufferedReader reader =
            new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Mini Interpreter started. Type 'help'.");

        try {
            while (true) {
                System.out.print("> ");
                String line = reader.readLine();
                if (line == null) break;                // EOF
                line = line.trim();
                if (line.isEmpty()) continue;           // skip blanks

                String[] parts = line.split("\\s+");
                String cmd = parts[0];

                switch (cmd) {
                    case "exit":
                        System.out.println("Exiting interpreter.");
                        return;

                    case "help":
                        printHelp();
                        break;

                    case "add":
                        if (parts.length != 3) {
                            System.out.println("Usage: add X Y");
                            break;
                        }
                        try {
                            long x = Long.parseLong(parts[1]);
                            long y = Long.parseLong(parts[2]);
                            System.out.println(x + y);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid numbers for add");
                        }
                        break;

                    case "mul":
                        if (parts.length != 3) {
                            System.out.println("Usage: mul X Y");
                            break;
                        }
                        try {
                            long x = Long.parseLong(parts[1]);
                            long y = Long.parseLong(parts[2]);
                            System.out.println(x * y);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid numbers for mul");
                        }
                        break;

                    case "fact":
                        if (parts.length != 2) {
                            System.out.println("Usage: fact X");
                            break;
                        }
                        try {
                            int n = Integer.parseInt(parts[1]);
                            if (n < 0) {
                                System.out.println("Invalid argument for factorial");
                                break;
                            }
                            System.out.println(factorial(n));
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid number for fact");
                        }
                        break;

                    default:
                        System.out.println("Unknown command");
                }
            }
        } catch (IOException e) {
            System.err.println("I/O error: " + e.getMessage());
        } finally {
            try { reader.close(); } catch (IOException ignored) {}
        }
    }

    private static void printHelp() {
        System.out.println("Available commands:");
        System.out.println("  add X Y   -> print X + Y");
        System.out.println("  mul X Y   -> print X * Y");
        System.out.println("  fact X    -> print factorial of X (X >= 0)");
        System.out.println("  help      -> list available commands");
        System.out.println("  exit      -> quit interpreter");
    }

    private static BigInteger factorial(int n) {
        BigInteger result = BigInteger.ONE;
        for (int i = 2; i <= n; i++) {
            result = result.multiply(BigInteger.valueOf(i));
        }
        return result;
    }
}