import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Treasure Matrix Hunt with Upgrades:
 *  • Explicit imports (no wildcards)
 *  • No method declares throws; all I/O errors are caught
 *  • CellType enum for strong typing
 *  • Multiple hunt modes and scan orders
 *  • ANSI‐colored console output
 */
public class TreasureMatrixHunt {

    // ANSI color codes
    private static final String RESET  = "\u001B[0m";
    private static final String RED    = "\u001B[31m";
    private static final String YELLOW = "\u001B[33m";
    private static final String GREEN  = "\u001B[32m";

    private enum CellType {
        EMPTY('.'), TREASURE('T'), TRAP('X');
        final char glyph;
        CellType(char g) { this.glyph = g; }
        static CellType fromChar(char c) {
            switch (c) {
                case 'T': return TREASURE;
                case 'X': return TRAP;
                default : return EMPTY;
            }
        }
    }

    private enum ScanOrder {
        ROW_WISE, COLUMN_WISE
    }

    private enum HuntMode {
        STOP_FIRST,    // stop at first trap or treasure
        COLLECT_ALL,   // collect all treasures until trap
        SHOW_PATH      // show full visited path up to event
    }

    private static class Coord {
        final int r, c;
        Coord(int r, int c) { this.r = r; this.c = c; }
        @Override public String toString() {
            return "(" + r + ", " + c + ")";
        }
    }

    public static void main(String[] args) {
        try (BufferedReader br = new BufferedReader(
                 new InputStreamReader(System.in))) {

            int rows = InputUtils.readPositiveInt(br, "Enter rows (M): ");
            int cols = InputUtils.readPositiveInt(br, "Enter columns (N): ");

            // Build and validate map
            CellType[][] map = new CellType[rows][cols];
            for (int r = 0; r < rows; r++) {
                while (true) {
                    String line = InputUtils
                        .readLine(br,
                            "Row " + r +
                            " (exactly " + cols + " chars . T X): ")
                        .replaceAll("\\s+", "");
                    if (line.length() != cols) {
                        System.out.println("Invalid length; retry.");
                        continue;
                    }
                    boolean ok = true;
                    for (int c = 0; c < cols; c++) {
                        char ch = line.charAt(c);
                        if (ch != '.' && ch != 'T' && ch != 'X') {
                            System.out.println(
                                "Invalid '" + ch +
                                "' at " + r + "," + c + "; retry.");
                            ok = false;
                            break;
                        }
                        map[r][c] = CellType.fromChar(ch);
                    }
                    if (ok) break;
                }
            }

            // Choose scan order
            System.out.println("\nScan orders:\n" +
                               "  1) Row-wise\n" +
                               "  2) Column-wise");
            int ordChoice = InputUtils.readChoice(br,
                "Select scan order (1–2): ", 1, 2);
            ScanOrder order = (ordChoice == 1
                ? ScanOrder.ROW_WISE
                : ScanOrder.COLUMN_WISE);

            // Choose hunt mode
            System.out.println("\nHunt modes:\n" +
                               "  1) Stop at first event\n" +
                               "  2) Collect treasures until trap\n" +
                               "  3) Show visited path");
            int modeChoice = InputUtils.readChoice(br,
                "Select mode (1–3): ", 1, 3);
            HuntMode mode = HuntMode.values()[modeChoice - 1];

            // Prepare visit sequence
            List<Coord> visits = new ArrayList<>();
            if (order == ScanOrder.ROW_WISE) {
                for (int r = 0; r < rows; r++)
                    for (int c = 0; c < cols; c++)
                        visits.add(new Coord(r, c));
            } else {
                for (int c = 0; c < cols; c++)
                    for (int r = 0; r < rows; r++)
                        visits.add(new Coord(r, c));
            }

            // Hunt logic
            boolean trapped = false, found = false;
            Coord firstTreasure = null;
            List<Coord> collected = new ArrayList<>();
            List<Coord> path = new ArrayList<>();

            for (Coord p : visits) {
                CellType cell = map[p.r][p.c];
                path.add(p);

                if (cell == CellType.TRAP) {
                    trapped = true;
                    break;
                }
                if (cell == CellType.TREASURE) {
                    if (mode == HuntMode.COLLECT_ALL) {
                        collected.add(p);
                        continue;
                    }
                    found = true;
                    firstTreasure = p;
                    break;
                }
            }

            // Display results
            System.out.println();
            switch (mode) {
                case STOP_FIRST:
                    if (trapped) {
                        System.out.println(RED + "Trapped!" + RESET);
                    } else if (found) {
                        System.out.println(YELLOW +
                            "Treasure at " + firstTreasure + RESET);
                    } else {
                        System.out.println("No treasure.");
                    }
                    break;

                case COLLECT_ALL:
                    if (collected.isEmpty() && !trapped) {
                        System.out.println("No treasure found.");
                    } else {
                        if (!collected.isEmpty()) {
                            System.out.println(YELLOW +
                                "Collected at " + collected + RESET);
                        }
                        if (trapped) {
                            System.out.println(RED + "Then trapped!" + RESET);
                        }
                    }
                    break;

                case SHOW_PATH:
                    System.out.println(GREEN +
                        "Visited path: " + path + RESET);
                    if (trapped) {
                        System.out.println(RED + "Stopped by trap." + RESET);
                    } else if (found) {
                        System.out.println(YELLOW +
                            "Found treasure at " +
                            path.get(path.size()-1) + RESET);
                    } else {
                        System.out.println("No treasure encountered.");
                    }
                    break;
            }

        } catch (IOException e) {
            System.err.println("I/O Error: " + e.getMessage());
        }
    }

    private static class InputUtils {
        static String readLine(BufferedReader br, String prompt) {
            while (true) {
                System.out.print(prompt);
                try {
                    String line = br.readLine();
                    if (line != null) return line;
                } catch (IOException e) {
                    System.err.println("I/O error; retrying.");
                }
            }
        }

        static int readPositiveInt(BufferedReader br, String prompt) {
            while (true) {
                String s = readLine(br, prompt).trim();
                try {
                    int v = Integer.parseInt(s);
                    if (v > 0) return v;
                } catch (NumberFormatException e) {
                    // fall through
                }
                System.out.println("Enter a positive integer.");
            }
        }

        static int readChoice(BufferedReader br,
                              String prompt,
                              int low, int high) {
            while (true) {
                String s = readLine(br, prompt).trim();
                try {
                    int c = Integer.parseInt(s);
                    if (c >= low && c <= high) return c;
                } catch (NumberFormatException e) {
                    // fall through
                }
                System.out.println("Enter a number between " +
                                   low + " and " + high + ".");
            }
        }
    }
}