import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * TreasureMatrixHunt
 *
 * Scans an M×N grid to find the first treasure ('T') or trap ('X').
 * - If a trap is found first: prints "Trapped!" and stops.
 * - If a treasure is found first: prints its coordinates.
 * - If neither is found: prints "No treasure."
 *
 * Uses a labeled break to exit both loops immediately upon discovery.
 * Handles user input and input validation through console prompts.
 */

public class TreasureMatrixHunt {
	public static void main(String[] args) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {

			System.out.print("Enter number of rows (M): ");
			int M = Integer.parseInt(reader.readLine().trim());

			System.out.print("Enter number of columns (N): ");
			int N = Integer.parseInt(reader.readLine().trim());

			char[][] map = new char[M][N];
			for (int i = 0; i < M; i++) {
				while (true) {
					System.out.print("Enter row " + i +
									 " (exactly " + N +
									 " chars, use . T X): ");
					String line = reader.readLine().replaceAll("\\s+", "");
					if (line.length() != N) {
						System.out.println("Invalid length—please retry.");
						continue;
					}
					map[i] = line.toCharArray();
					break;
				}
			}

			boolean trapped = false;
			boolean found   = false;
			int treasureRow = -1, treasureCol = -1;

			outer:
			for (int row = 0; row < M; row++) {
				for (int col = 0; col < N; col++) {
					char cell = map[row][col];

					if (cell == 'X') {
						trapped = true;
						break outer;
					}
					if (cell == 'T') {
						found	   = true;
						treasureRow = row;
						treasureCol = col;
						break outer;
					}
				}
			}

			if (trapped) {
				System.out.println("Trapped!");
			} else if (found) {
				System.out.printf("Treasure at (%d, %d)%n",
								  treasureRow, treasureCol);
			} else {
				System.out.println("No treasure.");
			}

		} catch (IOException e) {
			System.err.println("I/O Error: " + e.getMessage());
		}
	}
}