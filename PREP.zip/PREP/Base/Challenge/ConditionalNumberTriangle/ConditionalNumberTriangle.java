import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Prints a conditional number triangle based on user input.
 * - Replaces prime numbers with '*'
 * - Skips multiples of 5
 * - Stops each row if the sum of printed (non-prime, non-skipped) numbers exceeds a threshold.
 * 
 * Enter number of rows (positive integer): 6
 * Enter threshold limit (non-negative integer): 3
	1
	1 *
	1 * *
	1 * * 4
	1 * * 4
	1 * * 4
 *
 * @author Venktatesh
 * @version 2.0
 * @since 2025-07-11
 */
 
public class ConditionalNumberTriangle {
	
	/* //Rough:
	public static void main(String[] args) {
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
			System.out.println("========= Conditional Number Pyramid with Primes and Thresholds =========");
			System.out.println("Enter a number for number of rows: ");
			int input = Integer.parseInt(reader.readLine());
			System.out.println("Enter a number for limit: ");
			int limit = Integer.parseInt(reader.readLine());
			if(input <= 0){
				System.out.println("Input must be a positive number. Exiting....");
				return;
			}
			for(int i = 1; i <= input; i++) {
				int sum = 0;
				for(int j = 1; j <= i; j++) {
					if(isPrime(j) && j%5 != 0) {
						System.out.print("* "); 
						continue;
					}
					if(j%5==0) continue;
					System.out.print(j+" ");
					if ((sum += j) > limit) break;
				}
				System.out.println();
			}
		} catch(IOException e) {
			System.err.println("Error while reading.");
		}
	}
	
	public static boolean isPrime(int k) {
		if(k <= 1) return false;
		if(k == 2) return true;
		if(k % 2 == 0) return false;
		for(int i = 3; i <= Math.sqrt(k); i += 2) {
			if(k%i ==0) {
				return false;
			}
		}
		return true;
	}
	*/
	
	//Neat:
	public static void main(String[] args) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
			System.out.println("========= Conditional Number triangle =========");
			int numberOfRows = getValidatedInteger(reader, "Enter number of rows (positive integer): ", true);
			int thresholdLimit = getValidatedInteger(reader, "Enter threshold limit (non-negative integer): ", false);
			printConditionalPyramid(numberOfRows, thresholdLimit);
		} catch (IOException e) {
			System.err.println("Error reading input. Please try again.");
		}
	}
	/**
	 * Validates user input as a positive or non-negative integer.
	 *
	 * @param reader BufferedReader for reading input
	 * @param prompt Prompt message to display
	 * @param mustBeStrictlyPositive true if input must be > 0, false if >= 0 is allowed
	 * @return validated integer input
	 * @throws IOException if input reading fails
	 */
	private static int getValidatedInteger(BufferedReader reader, String prompt, boolean mustBeStrictlyPositive) throws IOException {
		int value;
		while (true) {
			System.out.print(prompt);
			try {
				value = Integer.parseInt(reader.readLine());
				if (mustBeStrictlyPositive && value > 0) return value;
				if (!mustBeStrictlyPositive && value >= 0) return value;
				System.out.println("Please enter a " + (mustBeStrictlyPositive ? "positive" : "non-negative") + " number.");
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid integer.");
			}
		}
	}
	/**
	 * Prints the conditional triangle pattern based on the rules.
	 *
	 * @param totalRows Total number of rows to print
	 * @param threshold Threshold limit for numeric sum in each row
	 */
	private static void printConditionalPyramid(int totalRows, int threshold) {
		for (int row = 1; row <= totalRows; row++) {
			int rowSum = 0;
			for (int num = 1; num <= row; num++) {
				if (num % 5 == 0) {
					continue; // Skip multiples of 5
				}
				if (isPrime(num)) {
					System.out.print("* ");
					continue; // Prime numbers are printed as '*' but don't affect sum
				}
				System.out.print(num + " ");
				rowSum += num;
				if (rowSum + num > threshold) {
					break; // Stop if threshold is exceeded
				}
			}
			System.out.println(); // Move to next row
		}
	}
	/**
	 * Checks whether a number is prime.
	 *
	 * @param number The number to check
	 * @return true if the number is prime, false otherwise
	 */
	private static boolean isPrime(int number) {
		if (number <= 1) return false;
		if (number == 2) return true;
		if (number % 2 == 0) return false;
		for (int i = 3; i <= Math.sqrt(number); i += 2) {
			if (number % i == 0) return false;
		}
		return true;
	}
}
