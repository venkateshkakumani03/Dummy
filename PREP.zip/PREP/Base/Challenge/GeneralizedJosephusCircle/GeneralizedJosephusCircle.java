import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Josephus Problem:
 * Given N people standing in a circle, eliminate every K-th person
 * and print the order of elimination until one remains.
 * 
 * @author Venkatesh
 * @version 1.0
 * @since 2025-07-11
 */
public class GeneralizedJosephusCircle {

	public static void main(String[] args) {
		System.out.println("=== Generalized Josephus Problem ===");
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
			
			// 1 = auto  2 = manual
			int mode = readMode(reader,
				"Choose input mode:\n" +
				"  1 - Auto-populate [1..N]\n" +
				"  2 - Enter N values manually\n" +
				"Select mode (1 or 2): ");
				
			int n = readPositiveInt(reader, "Enter number of people (N): ");
			int k = readPositiveInt(reader, "Enter elimination step (K): ");

			List<Integer> initialCircle = new ArrayList<>(n);
			if (mode == 1) {
				// auto-populate 1..N
				for (int i = 1; i <= n; i++) {
					initialCircle.add(i);
				}
			} else {
				// manual entry
				System.out.println("Enter " + n + " integers (one per line):");
				for (int i = 0; i < n; i++) {
					try {
						String line = reader.readLine().trim();
						initialCircle.add(Integer.parseInt(line));
					} catch (NumberFormatException ex) {
						System.out.println("Invalid integer, please retry this entry.");
						i--;  // stay on same index
					}
				}
			}

			// ▶ Choose ONE of the two elimination methods:
			// List<Integer> eliminationOrder = josephusEliminationIndexMath(n, k);
			List<Integer> eliminationOrder = josephusEliminationDeque(initialCircle, k);

			System.out.println("Order of elimination: " + eliminationOrder);
			System.out.println("Last survivor: " +
				eliminationOrder.get(eliminationOrder.size() - 1));

		} catch (IOException e) {
			System.err.println("I/O Error: " + e.getMessage());
		}
	}

	// Prompt until user enters 1 or 2
	private static int readMode(BufferedReader reader, String prompt)
			throws IOException {
		while (true) {
			System.out.print(prompt);
			String line = reader.readLine().trim();
			if ("1".equals(line) || "2".equals(line)) {
				return Integer.parseInt(line);
			}
			System.out.println("Please enter 1 or 2.");
		}
	}

	// Prompt until user enters a positive integer
	private static int readPositiveInt(BufferedReader reader, String prompt)
			throws IOException {
		while (true) {
			System.out.print(prompt);
			String line = reader.readLine();
			try {
				int val = Integer.parseInt(line.trim());
				if (val > 0) return val;
				System.out.println("Value must be positive. Try again.");
			} catch (NumberFormatException ex) {
				System.out.println("Invalid integer. Try again.");
			}
		}
	}

	/**
	 * Method 1: Deque-based Josephus elimination.
	 * Rotate k-1 people to the back, then eliminate the k-th.
	 *
	 * @param init starting order of IDs
	 * @param k	elimination step
	 * @return	 elimination order
	 */
	private static List<Integer> josephusEliminationDeque(List<Integer> init, int k) {
		Deque<Integer> circle = new ArrayDeque<>(init);
		List<Integer> order = new ArrayList<>(init.size());

		while (!circle.isEmpty()) {
			// rotate k-1 people
			for (int i = 0; i < k - 1; i++) {
				circle.addLast(circle.removeFirst());
			}
			// eliminate the k-th
			order.add(circle.removeFirst());
		}
		return order;
	}

	/**
	 * Method 2: Index-math Josephus elimination using ArrayList.
	 * Calculate the removal index via modulo arithmetic.
	 *
	 * @param n total people (numbered 1..n)
	 * @param k elimination step
	 * @return  elimination order
	 */
	private static List<Integer> josephusEliminationIndexMath(int n, int k) {
		List<Integer> circle = new ArrayList<>();
		List<Integer> result = new ArrayList<>();

		for (int i = 1; i <= n; i++) {
			circle.add(i);
		}

		int index = 0;
		while (!circle.isEmpty()) {
			index = (index + k - 1) % circle.size();
			result.add(circle.remove(index));
		}
		return result;
	}
}