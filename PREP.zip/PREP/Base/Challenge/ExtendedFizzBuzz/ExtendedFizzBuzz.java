import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Extended FizzBuzz with Skip and Stop Conditions
 *
 * For integers from 1 to N:
 *   1. If the integer contains the digit '3', skip it.
 *   2. Else if divisible by 3 and 5, print "FizzBuzz".
 *   3. Else if divisible by 3, print "Fizz".
 *   4. Else if divisible by 5, print "Buzz".
 *   5. Else print the integer itself.
 *
 * Stop entirely once you've printed M lines of output.
 *
 * Input:
 *   N (1–1000)  maximum integer to check
 *   M (1–500)   number of valid lines to print
 */
public class ExtendedFizzBuzz {

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {

            int N = readBoundedInt(reader, "Enter N (1–1000): ", 1, 1000);
            int M = readBoundedInt(reader, "Enter M (1–500): ", 1, 500);

            int printed = 0;
            for (int i = 1; i <= N; i++) {
                // Stop if we've printed M lines
                if (printed >= M) {
                    break;
                }

                String s = Integer.toString(i);
                // 1) Skip numbers containing '3'
                if (s.indexOf('3') >= 0) {
                    continue;
                }

                // 2–5) FizzBuzz rules
                if (i % 15 == 0) {
                    System.out.println("FizzBuzz");
                }
                else if (i % 3 == 0) {
                    System.out.println("Fizz");
                }
                else if (i % 5 == 0) {
                    System.out.println("Buzz");
                }
                else {
                    System.out.println(i);
                }

                printed++;
            }

        } catch (IOException e) {
            System.err.println("I/O Error: " + e.getMessage());
        }
    }

    /**
     * Reads an integer within [min..max], reprompting on invalid input.
     */
    private static int readBoundedInt(BufferedReader reader,
                                      String prompt,
                                      int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                String line = reader.readLine();
                int val = Integer.parseInt(line.trim());
                if (val < min || val > max) {
                    System.out.println(
                        "Value must be between " + min +
                        " and " + max + ". Try again."
                    );
                    continue;
                }
                return val;
            } catch (NumberFormatException ex) {
                System.out.println("Invalid integer. Try again.");
            } catch (IOException ex) {
                System.err.println("I/O Error: " + ex.getMessage());
            }
        }
    }
}