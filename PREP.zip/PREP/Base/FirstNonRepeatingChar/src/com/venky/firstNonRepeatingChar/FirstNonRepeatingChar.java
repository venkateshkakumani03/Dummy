package com.venky.firstNonRepeatingChar;

import java.io.BufferedReader;import java.io.InputStreamReader;import java.io.IOException;import java.util.LinkedHashMap;import java.util.Map;

/**
 * FirstNonRepeatingChar - Finds the first non-repeating character in a string.
 *
 * @example
 * Input: swiss
 * Output: w
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class FirstNonRepeatingChar {
    public static void main(String[] args) {
        System.out.println("=== First Non-Repeating Char ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a string: ");
            System.out.println(firstNonRepeating(br.readLine()));
        } catch (IOException e) {
			System.out.println("Error: " + e.getMessage());
        }
    }

    private static char firstNonRepeating(String s) {
        Map<Character, Integer> freq = new LinkedHashMap<>();
        for (char c : s.toCharArray()) freq.merge(c, 1, Integer::sum); //Integer::sum is method reference used instaed of @sum method.
		for (var e : freq.entrySet()) if (e.getValue() == 1) return e.getKey();
        return '\0';
    }
}

/*
public static int sum(int a, int b) {
	return a + b;
}
*/
