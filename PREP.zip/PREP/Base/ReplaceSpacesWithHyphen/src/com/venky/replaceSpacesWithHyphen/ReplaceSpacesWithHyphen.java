package com.venky.replaceSpacesWithHyphen;

import java.io.BufferedReader;import java.io.InputStreamReader;import java.io.IOException;

/**
 * ReplaceSpacesWithHyphen - Replaces all spaces in a string with hyphens.
 *
 * @example
 * Input: hello world
 * Output: hello-world
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class ReplaceSpacesWithHyphen {
    public static void main(String[] args) {
        System.out.println("=== Replace Spaces ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a string: ");
            System.out.println(br.readLine().replace(' ', '-'));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
