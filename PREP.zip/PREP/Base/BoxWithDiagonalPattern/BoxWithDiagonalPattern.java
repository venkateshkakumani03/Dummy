import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/*

if input is 5 then 
* * * * * 
* *   * * 
*   *   * 
* *   * * 
* * * * * 

*/
public class BoxWithDiagonalPattern {

    public static void main(String[] args) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
		
            System.out.print("Enter the side length of the square: ");
			int n = Integer.parseInt(reader.readLine());
			
			for (int i = 0; i < n; i++) { // for rows
				for (int j = 0; j < n; j++) { // for columns
					// Check for boundary conditions (top, bottom, left, right edges)
					// Check for main diagonal (i == j)
					// Check for anti-diagonal (i + j == n - 1)
					if (i == 0 || i == n - 1 || j == 0 || j == n - 1 || i == j || i + j == n - 1) {
						System.out.print("* ");
					} else {
						System.out.print("  ");
					}
				}
				System.out.println();
			}
        
		} catch (IOException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

