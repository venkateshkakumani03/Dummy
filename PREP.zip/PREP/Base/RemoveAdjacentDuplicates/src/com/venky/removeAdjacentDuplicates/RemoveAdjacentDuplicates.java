package com.venky.removeAdjacentDuplicates;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * RemoveAdjacentDuplicates - Removes consecutive duplicate characters from a string.
 *
 * @example
 * Input: aaabccddd
 * Output: abcd
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class RemoveAdjacentDuplicates {
    public static void main(String[] args) {
        System.out.println("=== Remove Adjacent Duplicates ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a string: ");
            System.out.println(removeDuplicates(br.readLine()));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static String removeDuplicates(String s) {
        StringBuilder sb = new StringBuilder();
        char prev = '\0';
        for (char c : s.toCharArray()) {
            if (c != prev) sb.append(prev = c);
        }
        return sb.toString();
    }
}
