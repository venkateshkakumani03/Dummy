package com.venky.swapNumbers;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * SwapNumbers - Swaps two integers without using a temporary variable.
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class SwapNumbers {
    public static void main(String[] args) {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter first integer: ");
			int a = Integer.parseInt(br.readLine());
			
			System.out.print("Enter second integer: ");
			int b = Integer.parseInt(br.readLine());

			swap(a, b);
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    private static void swap(int x, int y) {
        System.out.printf("Before swap: x=%d, y=%d\n", x, y);
        x = x + y;
        y = x - y;
        x = x - y;
        System.out.printf("After swap: x=%d, y=%d\n", x, y);
    }
}
