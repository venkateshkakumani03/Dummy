import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * DiagonalSum - Computes sum of primary and secondary diagonals of a square matrix.
 *
 * @example
 * Input:
 * 3
 * 1 2 3
 * 4 5 6
 * 7 8 9
 * Output: Primary: 15, Secondary: 15
 *
 * @author Venkatesh
 * @since 2025-07-11
 * @version 1.0
 */

public class DiagonalSum {
    public static void main(String[] args) {
        System.out.println("=== Diagonal Sum ===");
        try (BufferedReader br=new BufferedReader(new InputStreamReader(System.in))) {
            int n=Integer.parseInt(br.readLine().trim());
            int[][] m=new int[n][n];
            for(int i=0;i<n;i++){
                String[] row=br.readLine().trim().split("\\s+");
                if(row.length!=n) throw new IllegalArgumentException("Expected " + n + " values.");
                for(int j=0;j<n;j++) m[i][j]=Integer.parseInt(row[j]);
            }
            int primary=0, secondary=0;
            for(int i=0;i<n;i++){
                primary += m[i][i];
                secondary += m[i][n-1-i];
            }
            System.out.printf("Primary: %d, Secondary: %d%n", primary, secondary);
        } catch(IOException|IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
