package com.venky.minMaxWithoutConditionals;

import java.util.Scanner;

/**
 * MinMaxWithoutConditionals
 *
 * Goal:
 * Reads a sequence of space-separated integers from standard input
 * and finds both the minimum and maximum values without using any
 * if/else statements, leveraging arithmetic and Math.abs().
 *
 * Constraints:
 * - No if/else statements for logic
 * - No Math.min()/Math.max()
 * - No use of lists, arrays, or collections to store input
 *
 * Time: O(n) — processes input in a single pass  
 * Space: O(1) — uses constant memory regardless of input size
 * 
 * Example:
 * Input: 3 9 -2 7  
 * Output: Min: -2 Max: 9
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 2
 */
 
public class MinMaxWithoutConditionals {
	public static void main(String[] args) {
		
		//V1
		
		System.out.println("Enter integers separated by spaces then  press Ctrl+D/Z for EOF:");
		Scanner scanner = new Scanner(System.in);
		
		// Initialize min and max with the first input value
		int first = scanner.nextInt();
		int min = first;
		int max = first;
		
		// Process remaining integers
		while (scanner.hasNextInt()) {
			int num = scanner.nextInt();
			max = (max + num + Math.abs(max - num)) / 2;
			min = (min + num - Math.abs(min - num)) / 2;
		}
		System.out.printf("Min: %d Max: %d%n", min, max);
		
		
		//V2
		/*
		System.out.println("Enter integers separated by spaces, then press Enter:");
        Scanner inputScanner = new Scanner(System.in);
		
        String line = inputScanner.nextLine().trim();
        // Use a second Scanner to parse the tokens in the line
        Scanner tokenScanner = new Scanner(line);
        if (!tokenScanner.hasNextInt()) {
            System.out.println("No numbers provided");
            return;
        }
        // Initialize min and max with the first number
        int first = tokenScanner.nextInt();
        int min = first;
        int max = first;
        while (tokenScanner.hasNextInt()) {
            int num = tokenScanner.nextInt();
            max = (max + num + Math.abs(max - num)) / 2;
            min = (min + num - Math.abs(min - num)) / 2;
        }
		System.out.printf("Min: %d Max: %d%n", min, max);
		*/
		
	}
}