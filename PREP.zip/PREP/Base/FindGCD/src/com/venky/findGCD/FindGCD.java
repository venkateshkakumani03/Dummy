package com.venky.findGCD;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * FindGCD - Computes the greatest common divisor using Euclidean algorithm.
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 * 
 */
public class FindGCD {
    public static void main(String[] args) {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter first integer: ");
			int a = Integer.parseInt(br.readLine());
			
			System.out.print("Enter second integer: ");
			int b = Integer.parseInt(br.readLine());
			
			System.out.println("GCD: " + gcd(a, b));
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    private static int gcd(int a, int b) {
        return b == 0 ? Math.abs(a) : gcd(b, a % b);
    }
}
