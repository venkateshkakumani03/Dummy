package com.venky.missingNumber;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * MissingNumber - Finds the missing number in a sequence from 1 to N.
 *
 * @example
 * Input: 1 2 4 5 (N=5)
 * Output: Missing number is 3
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
 
public class MissingNumber {
    public static void main(String[] args) {
        System.out.println("=== Missing Number Finder ===");

        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter value of N: ");
            int n = Integer.parseInt(br.readLine());

            System.out.print("Enter up to " + (n - 1) + " numbers separated by spaces: ");
            String[] tokens = br.readLine().trim().split("\\s+");

            boolean[] present = new boolean[n + 1]; // Index 1 to n

            for (String token : tokens) {
                int num = Integer.parseInt(token);
                if (num >= 1 && num <= n) {
                    present[num] = true;
                } else {
                    System.out.println("Ignored out-of-range value: " + num);
                }
            }

            System.out.print("Missing number(s): ");
            boolean missingFound = false;
            for (int i = 1; i <= n; i++) {
                if (!present[i]) {
                    System.out.print(i + " ");
                    missingFound = true;
                }
            }

            if (!missingFound) {
                System.out.print("None — all values from 1 to " + n + " are present.");
            }

        } catch (IOException | NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
