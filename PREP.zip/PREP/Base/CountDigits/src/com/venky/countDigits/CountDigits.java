package com.venky.countDigits;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Counts the number of digits in an given integer.
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 *
 */
public class CountDigits {
    public static void main(String[] args) {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter an integer: ");
			long n = Long.parseLong(br.readLine());
			System.out.println("Digit count: " + countDigits(n));
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    private static int countDigits(long n) {
        if (n == 0) return 1;
        int count = 0;
        while (n != 0) {
            count++;
            n /= 10;
        }
        return count;
    }
}
