package com.venky.reverseNumber;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Reverses the digits of an integer.
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 * 
 */
public class ReverseNumber {
    public static void main(String[] args) {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
		
			System.out.print("Enter an integer: ");
			int n = Integer.parseInt(br.readLine());
			System.out.println("Reversed number: " + reverse(n));
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		} catch (IOException e) {
            System.out.println("Error reading input: " + e.getMessage());
        }
    }

    private static int reverse(int n) {
        int rev = 0;
        while (n != 0) {
            rev = rev * 10 + n % 10;
            n /= 10;
        }
        return rev;
    }
}
