package com.venky.balancedParentheses;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Stack;
import java.util.Map;

/**
 * BalancedParentheses - Checks if parentheses are balanced in a string.
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 *
 */
public class BalancedParentheses {
    public static void main(String[] args) {  
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter a parentheses string: ");
			String s = br.readLine();
			System.out.println(isBalanced(s) ? "Balanced" : "Not Balanced");
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    /* only works for - ()
	private static boolean isBalanced(String s) {
        Stack<Character> st = new Stack<>();
        for (char c : s.toCharArray()) {
            if (c == '(') st.push(c);
            else if (c == ')' && !st.isEmpty()) st.pop();
            else return false;
        }
        return st.isEmpty();
    }
	*/
	
	private static boolean isBalanced(String s) {
		Stack<Character> st = new Stack<>();
		Map <Character, Character> pairs = Map.of(
			')', '(', 
			']', '[', 
			'}', '{'
		);

		for (char c : s.toCharArray()) {
			if (pairs.containsValue(c)) {
				st.push(c); // opening bracket
			} else if (pairs.containsKey(c)) {
				if (st.isEmpty() || st.pop() != pairs.get(c)) return false;
			}
		}

		return st.isEmpty(); // stack should be empty if all matched
	}
}

	