package com.venky.matrixTranspose;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * MatrixTranspose - Transposes a 2D matrix.
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 * 
 */
public class MatrixTranspose {
    public static void main(String[] args) throws Exception {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter rows and columns seperated by space: ");
			String[] dims = br.readLine().split("\\s+");
			int r = Integer.parseInt(dims[0]), c = Integer.parseInt(dims[1]);
			int[][] matrix = new int[r][c];
			
			System.out.println("Enter matrix values row by row:");
			for (int i = 0; i < r; i++) {
				String[] parts = br.readLine().split("\\s+");
				for (int j = 0; j < c; j++) matrix[i][j] = Integer.parseInt(parts[j]);
			}
			
			int[][] t = transpose(matrix);
			System.out.println("Transposed Matrix:");
			for (int[] row : t) {
				for (int v : row) System.out.print(v + " ");
				System.out.println();
			}
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    private static int[][] transpose(int[][] m) {
        int r = m.length, c = m[0].length;
        int[][] t = new int[c][r];
        for (int i = 0; i < r; i++)
            for (int j = 0; j < c; j++) t[j][i] = m[i][j];
        return t;
    }
}
