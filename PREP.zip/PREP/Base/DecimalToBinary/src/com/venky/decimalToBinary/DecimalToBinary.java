package com.venky.decimalToBinary;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * DecimalToBinary - Converts a decimal number to binary string.
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 * 
 */
public class DecimalToBinary {
    public static void main(String[] args) {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter decimal integer: ");
			int n = Integer.parseInt(br.readLine());
			System.out.println("Binary: " + toBinary(n));
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    private static String toBinary(int n) {
        if (n == 0) return "0";
        StringBuilder sb = new StringBuilder();
        while (n != 0) {
            sb.append(n & 1);
            n >>>= 1;
        }
        return sb.reverse().toString();
    }
}
