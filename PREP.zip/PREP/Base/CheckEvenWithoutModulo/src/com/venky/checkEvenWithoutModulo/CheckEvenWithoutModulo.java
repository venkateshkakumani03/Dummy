package com.venky.checkEvenWithoutModulo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * CheckEvenWithoutModulo - Determines if a number is even without using % operator.
 *
 * even numbers always end in 0, while odd numbers always end in 1
 * (n & 1) helps us to LSB(Least Significant Bit) i.e., last bit.
 *
 * @example
 * Input: 8
 * Output: 8 is even
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class CheckEvenWithoutModulo {
    public static void main(String[] args) {
        System.out.println("=== Even Checker (No Modulo) ===");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a number: ");
            int n = Integer.parseInt(reader.readLine());
            System.out.println(n + (isEven(n) ? " is even" : " is odd"));
        } catch (NumberFormatException | IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static boolean isEven(int n) {
        return (n & 1) == 0;
    }
}