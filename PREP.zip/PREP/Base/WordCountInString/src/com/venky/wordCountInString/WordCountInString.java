package com.venky.wordCountInString;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * WordCountInString - Counts the number of words in a string.
 *
 * @example
 * Input: hello world from java
 * Output: Word count: 4
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class WordCountInString {
    public static void main(String[] args) {
        System.out.println("=== Word Count ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a string: ");
            String input = br.readLine();
            System.out.println("Word count: " + countWords(input));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static int countWords(String s) {
        if (s == null || s.isEmpty()) return 0;
        String[] parts = s.trim().split("\s+");
        return parts.length;
    }
}
