package com.venky.perfectNumber;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * PerfectNumberCheck - Determines if a number is perfect.
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 *
 * A perfect number is a positive integer that equals the sum of its proper divisors (the positive divisors excluding the number itself). 
 * For example: 
 * The number 6 is a perfect number because its proper divisors are 1, 2, and 3, and 1 + 2 + 3 = 6
 * 
 */
public class PerfectNumberCheck {
    public static void main(String[] args) throws Exception {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter a positive integer: ");
			int n = Integer.parseInt(br.readLine());
			System.out.println(n + (isPerfect(n) ? " is a perfect number" : " is not perfect"));
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    private static boolean isPerfect(int n) {
        if (n <= 1) return false;
        int sum = 1;
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) sum += i;
        }
        return sum == n;
    }
}
