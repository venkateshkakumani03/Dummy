import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;

/**
 * @author Venkatesh
 * @since 2025-07-11
 * @version 1.0
 */

public class MatrixMultiplication {
    public static void main(String[] args) {
        System.out.println("=== Matrix Multiplication ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            int[] d1 = readDims(br, "Enter rows and cols of A: ");
            int[][] A = readMatrix(br, d1, "Enter matrix A:");
            int[] d2 = readDims(br, "Enter rows and cols of B: ");
            int[][] B = readMatrix(br, d2, "Enter matrix B:");
            if (d1[1] != d2[0]) throw new IllegalArgumentException("A's cols must match B's rows.");
            int[][] P = multiply(A, B);
            System.out.println("Product Matrix:"); printMatrix(P);
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static int[] readDims(BufferedReader br, String prompt) throws IOException {
        System.out.print(prompt);
        String[] p = br.readLine().trim().split("\\s+"); 
		if (p.length!=2) throw new IllegalArgumentException("Two ints expected.");
        return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])};
    }

    private static int[][] readMatrix(BufferedReader br, int[] d, String prompt) throws IOException {
        int r=d[0], c=d[1]; 
		System.out.println(prompt);
        int[][] m=new int[r][c]; 
		for(int i=0;i<r;i++){ 
			String[] row=br.readLine().trim().split("\\s+"); 
			if(row.length!=c) throw new IllegalArgumentException("Expected "+c+" values."); 
			for(int j=0;j<c;j++) m[i][j]=Integer.parseInt(row[j]); 
		}
        return m;
    }

    private static int[][] multiply(int[][] A, int[][] B){
        int r=A.length, c=B[0].length, common=A[0].length;
        int[][] R=new int[r][c];
        for(int i=0;i<r;i++) for(int j=0;j<c;j++) for(int k=0;k<common;k++) R[i][j]+=A[i][k]*B[k][j];
        return R;
    }
    
	private static void printMatrix(int[][] m){ 
		for(int[] row:m) System.out.println(Arrays.toString(row));
	}
}
