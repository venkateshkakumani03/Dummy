package com.venky.stringToIntegerManualParse;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * StringToIntegerManualParse - Parses a numeric string to integer without using parseInt.
 *
 * @example
 * Input: 12345
 * Output: 12345
 *
 *Let’s say c = '5'.
 * Characters in Java are essentially integer values from the ASCII table.
 * - '0' → ASCII value 48
 * - '5' → ASCII value 53
 * '5' - '0' → 53 - 48 → 5 (Done)
 *
 * if i use: .getClass() the output is something like this class java.lang.String
 * if i use: .getClass().getName() the output is something like this java.lang.String
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class StringToIntegerManualParse {
    public static void main(String[] args) {
        System.out.println("=== String to Integer Parser ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a numeric string: ");
            String s = br.readLine();
			System.out.println("Type of s: " + s.getClass().getName());
			Integer goal = toInteger(s); //used Integer because if i used int i cant know which class it is belonged to as int doesn't have methods like .getClass()
            System.out.println("Parsed integer: " + goal);
			System.out.println("Type of result: " + goal.getClass().getName());
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid numeric string.");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static int toInteger(String s) {
        if (s == null || s.isEmpty()) throw new IllegalArgumentException();
        int result = 0;
        int i = 0;
        boolean negative = false;
        if (s.charAt(0) == '-') {
            negative = true;
            i = 1;
        }
        for (; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < '0' || c > '9') throw new IllegalArgumentException();
            result = result * 10 + (c - '0');
        }
        return negative ? -result : result;
    }
}
