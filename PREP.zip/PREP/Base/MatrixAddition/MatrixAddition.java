import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;

/**
 * @author Venkatesh
 * @since 2025-07-11
 * @version 1.0
 */

public class MatrixAddition {
    public static void main(String[] args) {
        System.out.println("=== Matrix Addition ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            int[] dims = readDims(br, "Enter rows and cols of matrix A: ");
            int[][] A = readMatrix(br, dims, "Enter matrix A:");
            int[] dimsB = readDims(br, "Enter rows and cols of matrix B: ");
            int[][] B = readMatrix(br, dimsB, "Enter matrix B:");
            if (dims[0] != dimsB[0] || dims[1] != dimsB[1]) {
                throw new IllegalArgumentException("Matrices must have same dimensions.");
            }
            int[][] sum = add(A, B);
            System.out.println("Sum Matrix:");
            printMatrix(sum);
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static int[] readDims(BufferedReader br, String prompt) throws IOException {
        System.out.print(prompt);
        String[] parts = br.readLine().trim().split("\\s+");
        if (parts.length != 2) throw new IllegalArgumentException("Expected two integers.");
        return new int[]{Integer.parseInt(parts[0]), Integer.parseInt(parts[1])};
    }

    private static int[][] readMatrix(BufferedReader br, int[] dims, String prompt) throws IOException {
        int r = dims[0], c = dims[1];
        System.out.println(prompt);
        int[][] m = new int[r][c];
        for (int i = 0; i < r; i++) {
            String[] row = br.readLine().trim().split("\\s+");
            if (row.length != c) throw new IllegalArgumentException("Expected " + c + " values per row.");
            for (int j = 0; j < c; j++) m[i][j] = Integer.parseInt(row[j]);
        }
        return m;
    }

    private static int[][] add(int[][] A, int[][] B) {
        int r = A.length, c = A[0].length;
        int[][] C = new int[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                C[i][j] = A[i][j] + B[i][j];
            }
        }
        return C;
    }

    private static void printMatrix(int[][] m) {
        for (int[] row : m) {
            System.out.println(Arrays.toString(row));
        }
    }
}
