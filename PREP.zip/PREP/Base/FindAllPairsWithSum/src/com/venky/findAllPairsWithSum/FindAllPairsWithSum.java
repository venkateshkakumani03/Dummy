package com.venky.findAllPairsWithSum;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Finds all pairs in an array whose sum equals a target value.
 *
 * @example
 * Input:
 * Enter size: 5
 * Enter elements: 1 2 3 4 5
 * Enter target sum: 6
 * Output:
 * Pairs: (1,5), (2,4)
 *
 * @author Venkatesh
 * @version 1.0
 * @since 2025-07-10
 */
 
public class FindAllPairsWithSum {
    public static void main(String[] args) {
        System.out.println("=== Find Pairs With Given Sum ===");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            int size = readInt(reader, "Enter size: ", 1, Integer.MAX_VALUE);
            int[] arr = readArray(reader, size, "Enter elements: ");
            int target = readInt(reader, "Enter target sum: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
            findAndPrintPairs(arr, target);
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
	
    private static void findAndPrintPairs(int[] arr, int target) {
        Map<Integer, Boolean> map = new HashMap<>();
        System.out.print("Pairs: ");
        boolean found = false;
        for (int num : arr) {
            int complement = target - num;
            if (map.containsKey(complement)) {
                System.out.print("(" + complement + "," + num + ") ");
                found = true;
            }
            map.put(num, true);
        }
        if (!found) System.out.print("None");
        System.out.println();
    }
	
    private static int readInt(BufferedReader reader, String prompt, int min, int max) throws IOException {
        System.out.print(prompt);
        int val = Integer.parseInt(reader.readLine().trim());
        if (val < min || val > max) {
            throw new IllegalArgumentException("Value must be between " + min + " and " + max);
        }
        return val;
    }
	
    private static int[] readArray(BufferedReader reader, int n, String prompt) throws IOException {
        System.out.print(prompt);
        String[] parts = reader.readLine().trim().split("\\s+");
        if (parts.length != n) throw new IllegalArgumentException("Expected " + n + " values.");
        int[] res = new int[n];
        for (int i = 0; i < n; i++) res[i] = Integer.parseInt(parts[i]);
        return res;
    }
}
