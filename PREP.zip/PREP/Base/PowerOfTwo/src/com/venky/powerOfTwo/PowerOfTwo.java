package com.venky.powerOfTwo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * PowerOfTwo - Checks whether a number is a power of two.
 *
 * @example
 * Input: 16
 * Output: Is power of two: true
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class PowerOfTwo {
    public static void main(String[] args) {
        System.out.println("=== Power of Two Checker ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
            System.out.print("Enter a number: ");
            int n = Integer.parseInt(br.readLine());
            boolean result = isPowerOfTwo(n);
            System.out.println("Is power of two: " + result);
			
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid integer.");
        } catch (IOException e) {
            System.out.println("I/O error: " + e.getMessage());
        }
    }

    private static boolean isPowerOfTwo(int n) {
        return n > 0 && (n & (n - 1)) == 0;
    }
}
