package com.venky.toggleCharCase;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * ToggleCharCase (or) CaseFlipping - Toggles the case of all alphabetic characters in a string.
 *
 * @example
 * Input: Hello World!
 * Output: hELLO wORLD!
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class ToggleCharCase {
    public static void main(String[] args) {
        System.out.println("=== Toggle Character Case ===");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a string: ");
            String s = reader.readLine();
            System.out.println(toggleCase(s));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static String toggleCase(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (Character.isUpperCase(c)) sb.append(Character.toLowerCase(c));
            else if (Character.isLowerCase(c)) sb.append(Character.toUpperCase(c));
            else sb.append(c);
        }
        return sb.toString();
    }
}