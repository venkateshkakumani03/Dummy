package com.venky.toggleVowelsOnly;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * ToggleVowelsOnly - Toggles the case of vowels in a string.
 *
 * @example
 * Input: Hello World
 * Output: HEllO WOrld
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class ToggleVowelsOnly {
    public static void main(String[] args) {
        System.out.println("=== Toggle Vowels Only ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a string: ");
            System.out.println(toggleVowels(br.readLine()));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static String toggleVowels(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if ("aeiouAEIOU".indexOf(c) >= 0) {
                if (Character.isLowerCase(c)) sb.append(Character.toUpperCase(c));
                else sb.append(Character.toLowerCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
