package com.venky.arrayIntersection;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * Finds common elements (intersection) between two integer arrays.
 *
 * @example
 * Input:
 * Enter size of array A: 4
 * Enter elements of A: 1 2 3 4
 * Enter size of array B: 3
 * Enter elements of B: 3 4 5
 * Output:
 * Intersection: [3, 4]
 *
 * @author Venkatesh
 * @version 1.0
 * @since 2025-07-10
 */

public class ArrayIntersection {
    public static void main(String[] args) {
        System.out.println("=== Array Intersection ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
		
            int n = readInt(br, "Enter size of array A: ", 1, Integer.MAX_VALUE);
            int[] a = readArray(br, n, "Enter elements of A: ");
            int m = readInt(br, "Enter size of array B: ", 1, Integer.MAX_VALUE);
            int[] b = readArray(br, m, "Enter elements of B: ");
        
			Set<Integer> intersection = findIntersection(a, b);
            System.out.println("Intersection: " + intersection);
        
		} catch (IOException | IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static Set<Integer> findIntersection(int[] a, int[] b) {
        Set<Integer> setA = new HashSet<>();
        Set<Integer> result = new HashSet<>();
        for (int x : a) setA.add(x);
        for (int x : b) if (setA.contains(x)) result.add(x);
        return result;
    }

    private static int readInt(BufferedReader br, String prompt, int min, int max) throws IOException {
        System.out.print(prompt);
        int val = Integer.parseInt(br.readLine().trim());
        if (val < min || val > max) {
            throw new IllegalArgumentException("Value must be between " + min + " and " + max);
        }
        return val;
    }

    private static int[] readArray(BufferedReader br, int n, String prompt) throws IOException {
        System.out.print(prompt);
        String[] parts = br.readLine().trim().split("\\s+");
        if (parts.length != n) throw new IllegalArgumentException("Expected " + n + " values.");
        int[] res = new int[n];
        for (int i = 0; i < n; i++) res[i] = Integer.parseInt(parts[i]);
        return res;
    }
}