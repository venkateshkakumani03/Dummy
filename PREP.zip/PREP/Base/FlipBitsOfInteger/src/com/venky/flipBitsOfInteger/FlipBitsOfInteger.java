package com.venky.flipBitsOfInteger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * FlipBitsOfInteger - Flips all bits of an integer (bitwise NOT).
 *
 * @example
 * Input: 5 (0101)
 * Output: ~5 = -6 (two's complement)
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class FlipBitsOfInteger {
    public static void main(String[] args) {
        System.out.println("=== Flip Bits of Integer ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a number: ");
            int n = Integer.parseInt(br.readLine());
            System.out.println("Flipped: " + (~n));
        } catch (NumberFormatException | IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}