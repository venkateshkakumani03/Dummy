package com.venky.sumOfDigits;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * SumOfDigits - Calculates the sum of digits of an integer.
	e.g: Sample-input: 153 
		output:9 i.e., 1+5+3=9
 * 
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 *
 */
public class SumOfDigits {
    public static void main(String[] args) {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			
			System.out.print("Enter an integer: ");
			int n = Integer.parseInt(br.readLine());
			System.out.println("Sum of digits: " + sumDigits(n));
			
		} catch(IOException e) {
			System.err.println("Erroe While reading.");
		}
    }

    private static int sumDigits(int n) {
        int sum = 0;
        while (n != 0) {
            sum += Math.abs(n % 10);
            n /= 10;
        }
        return sum;
    }
}
