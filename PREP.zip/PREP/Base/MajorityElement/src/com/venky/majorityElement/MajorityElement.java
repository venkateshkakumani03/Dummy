package com.venky.majorityElement;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * MajorityElement - Finds the element that appears more than n/2 times.
 *
 * @example
 * Input: 3 3 4 2 3 3 3
 * Output: Majority element is: 3
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */

public class MajorityElement {
    public static void main(String[] args) {
        System.out.println("=== Majority Element Finder ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter number of elements: ");
            int n = Integer.parseInt(br.readLine());
            int[] arr = new int[n];
            System.out.println("Enter " + n + " elements:");
            for (int i = 0; i < n; i++) arr[i] = Integer.parseInt(br.readLine());
            int candidate = findCandidate(arr);
            if (isMajority(arr, candidate))
                System.out.println("Majority element is: " + candidate);
            else
                System.out.println("No majority element.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
	
    private static int findCandidate(int[] arr) {
        int count = 0, candidate = -1;
        for (int num : arr) {
            if (count == 0) {
                candidate = num;
                count = 1;
            } else if (candidate == num) {
                count++;
            } else {
                count--;
            }
        }
        return candidate;
    }
	
    private static boolean isMajority(int[] arr, int candidate) {
        int count = 0;
        for (int num : arr) {
            if (num == candidate) count++;
        }
        return count > arr.length / 2;
    }
}