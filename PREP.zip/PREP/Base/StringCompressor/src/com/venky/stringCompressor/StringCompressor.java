package com.venky.stringCompressor;

import java.io.BufferedReader;import java.io.InputStreamReader;import java.io.IOException;

/**
 * StringCompressor - Compresses string using run-length encoding.
 *
 * @example
 * Input: aaabbc
 * Output: a3b2c1
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 1.0
 */
public class StringCompressor {
    public static void main(String[] args) {
        System.out.println("=== String Compressor ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a string: ");
            System.out.println(compress(br.readLine()));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static String compress(String s) {
        StringBuilder sb = new StringBuilder();
        int count = 1;
        for (int i = 1; i <= s.length(); i++) {
            if (i < s.length() && s.charAt(i) == s.charAt(i - 1)) count++;
            else {
                sb.append(s.charAt(i - 1)).append(count);
                count = 1;
            }
        }
        return sb.toString();
    }
}
