package com.venky.longestPrefixFinder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils; // Don't forget to add lib while compiling and running. Accordinng to the "helper method - version" u are using.

/**
 * LongestPrefixFinder - Finds the longest common prefix among an array of strings.
 *
 * @example
 * Input: [flower, flow, flight]
 * Output: fl
 *
 * @author Venkatesh
 * @since 2025-07-08
 * @version 2.0
 */
public class LongestPrefixFinder {
    public static void main(String[] args) {
        System.out.println("=== Longest Common Prefix ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter comma-separated strings: ");
            String[] arr = br.readLine().split(",");
            System.out.println("Prefix: " + longestCommonPrefix(arr));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

	//v1
	/*
    private static String longestCommonPrefix(String[] strs) {
        if (strs == null || strs.length == 0) return "";
        String prefix = strs[0];
        for (int i = 1; i < strs.length; i++) {
            while (!strs[i].startsWith(prefix)) {
                prefix = prefix.substring(0, prefix.length() - 1);
                if (prefix.isEmpty()) return "";
            }
        }
        return prefix;
    }
	*/
	
	//v2
	private static String longestCommonPrefix(String[] strs) {
        if (strs == null || strs.length == 0) return "";
        String prefix = StringUtils.trimToEmpty(strs[0]); // ✅ Null-safe and whitespace trimmed
        for (int i = 1; i < strs.length; i++) {
            String current = StringUtils.trimToEmpty(strs[i]);
            while (!StringUtils.startsWith(current, prefix)) {
                prefix = StringUtils.left(prefix, prefix.length() - 1); // trims last char
                if (StringUtils.isEmpty(prefix)) return "";
            }
        }
        return prefix;
    }
}
