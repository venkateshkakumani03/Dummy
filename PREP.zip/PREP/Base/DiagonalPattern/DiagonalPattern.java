/*

*       * 
  *   *   
    *     
  *   *   
*       * 

*/

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class DiagonalPattern {

    public static void main(String[] args) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
		
            System.out.print("Enter the side length of the square: ");
			int n = Integer.parseInt(reader.readLine());
			
			for (int i = 0; i < n; i++) { 
				for (int j = 0; j < n; j++) { 
					if (i == j || i + j == n - 1) {
						System.out.print("* ");
					} else {
						System.out.print("  ");
					}
				}
				System.out.println();
			}
        
		} catch (IOException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}