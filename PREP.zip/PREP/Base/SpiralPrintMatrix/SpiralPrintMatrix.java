import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * SpiralPrintMatrix - Prints elements of a matrix in spiral order.
 *
 * @example
 * Input:
 * 3 3
 * 1 2 3
 * 4 5 6
 * 7 8 9
 * Output: [1, 2, 3, 6, 9, 8, 7, 4, 5]
 *
 * @author Venkatesh
 * @since 2025-07-11
 * @version 1.0
 */

public class SpiralPrintMatrix {
    public static void main(String[] args) {
        System.out.println("=== Spiral Print Matrix ===");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            int[] d = readDims(br, "Enter rows and cols: ");
            int[][] m = readMatrix(br, d, "Enter matrix:");
            List<Integer> spiral = spiralOrder(m);
            System.out.println(spiral);
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static List<Integer> spiralOrder(int[][] m) {
        List<Integer> res = new ArrayList<>();
        int top = 0, bottom = m.length - 1, left = 0, right = m[0].length - 1;
        while (top <= bottom && left <= right) {
            for (int j = left; j <= right; j++) res.add(m[top][j]);
            top++;
            for (int i = top; i <= bottom; i++) res.add(m[i][right]);
            right--;
            if (top <= bottom) {
                for (int j = right; j >= left; j--) res.add(m[bottom][j]);
                bottom--;
            }
            if (left <= right) {
                for (int i = bottom; i >= top; i--) res.add(m[i][left]);
                left++;
            }
        }
        return res;
    }

    private static int[] readDims(BufferedReader br, String prompt) throws IOException {
        System.out.print(prompt);
		String[] p=br.readLine().trim().split("\\s+");
		if(p.length!=2) throw new IllegalArgumentException("Two ints expected.");
		return new int[]{Integer.parseInt(p[0]),Integer.parseInt(p[1])};
    }

    private static int[][] readMatrix(BufferedReader br,int[] d,String prompt) throws IOException {
        System.out.println(prompt); 
		int r=d[0],c=d[1]; 
		int[][] m=new int[r][c]; 
		for(int i=0;i<r;i++){ 
			String[] row=br.readLine().trim().split("\\s+"); 
			if(row.length!=c) throw new IllegalArgumentException("Expected "+c+" values."); 
			for(int j=0;j<c;j++) m[i][j]=Integer.parseInt(row[j]); 
		} 
		return m;
    }
}
