import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class ArrayReverse {

    public static void main(String[] args) {
        try {
            int[] array = readArrayFromUser();
            reverseArray(array);
            printArray(array);
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format. Please enter integers only.");
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static int[] readArrayFromUser() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter the number of elements: ");
        int size = Integer.parseInt(reader.readLine());

        if (size <= 0) {
            throw new IllegalArgumentException("Array size must be greater than zero.");
        }

        int[] array = new int[size];

        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            array[i] = Integer.parseInt(reader.readLine());
        }

        return array;
    }

    private static void reverseArray(int[] array) {
        int left = 0;
        int right = array.length - 1;

        while (left < right) {
            int temp = array[left];
            array[left] = array[right];
            array[right] = temp;
            left++;
            right--;
        }
    }

    private static void printArray(int[] array) {
        System.out.print("Reversed array: ");
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

//All in main mthod
/*
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class ArrayReverse {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the number of elements: ");
            int size = Integer.parseInt(reader.readLine());

            if (size <= 0) {
                System.err.println("Array size must be greater than zero.");
                return;
            }

            int[] array = new int[size];
            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                array[i] = Integer.parseInt(reader.readLine());
            }

            int left = 0;
            int right = array.length - 1;
            while (left < right) {
                int temp = array[left];
                array[left] = array[right];
                array[right] = temp;
                left++;
                right--;
            }

            System.out.print("Reversed array: ");
            for (int num : array) {
                System.out.print(num + " ");
            }
            System.out.println();

        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format. Please enter integers only.");
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
*/