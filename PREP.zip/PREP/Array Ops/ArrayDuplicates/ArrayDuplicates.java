import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * The {@code ArrayDuplicates} class provides functionality to read an array of integers
 * from the user and identify duplicate elements within the array.
 * <p>
 * It uses a {@link HashSet} to track seen elements and another {@link HashSet} to store duplicates.
 * </p>
 * 
 * @author Venkatesh Kakumani
 * @version 1.0
 */
public class ArrayDuplicates {

    /**
     * The main method serves as the entry point of the program.
     * It reads an array from the user, finds duplicates, and prints them.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        try {
            int[] array = readArrayFromUser();
            Set<Integer> duplicates = findDuplicates(array);
            printDuplicates(duplicates);
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format. Please enter integers only.");
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    /**
     * Reads an array of integers from the user using {@link BufferedReader}.
     *
     * @return an array of integers entered by the user
     * @throws IOException if an input or output exception occurs
     * @throws NumberFormatException if the input is not a valid integer
     * @throws IllegalArgumentException if the array size is less than or equal to zero
     */
    private static int[] readArrayFromUser() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter the number of elements: ");
        int size = Integer.parseInt(reader.readLine());

        if (size <= 0) {
            throw new IllegalArgumentException("Array size must be greater than zero.");
        }

        int[] array = new int[size];

        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            array[i] = Integer.parseInt(reader.readLine());
        }

        return array;
    }

    /**
     * Finds and returns a set of duplicate elements in the given array.
     *
     * @param array the array to search for duplicates
     * @return a set containing duplicate elements
     */
    private static Set<Integer> findDuplicates(int[] array) {
        Set<Integer> seen = new HashSet<>();
        Set<Integer> duplicates = new HashSet<>();

        for (int number : array) {
            if (!seen.add(number)) {
                duplicates.add(number);
            }
        }

        return duplicates;
    }

    /**
     * Prints the duplicate elements found in the array.
     *
     * @param duplicates a set of duplicate integers
     */
    private static void printDuplicates(Set<Integer> duplicates) {
        if (duplicates.isEmpty()) {
            System.out.println("No duplicate elements found.");
        } else {
            System.out.println("Duplicate elements: " + duplicates);
        }
    }
}


//All in main method
/*
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class ArrayDuplicates {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            System.out.print("Enter the number of elements: ");
            int size = Integer.parseInt(reader.readLine());

            if (size <= 0) {
                System.err.println("Array size must be greater than zero.");
                return;
            }

            int[] array = new int[size];
            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                array[i] = Integer.parseInt(reader.readLine());
            }

            Set<Integer> seen = new HashSet<>();
            Set<Integer> duplicates = new HashSet<>();

            for (int number : array) {
                if (!seen.add(number)) {
                    duplicates.add(number);
                }
            }

            if (duplicates.isEmpty()) {
                System.out.println("No duplicate elements found.");
            } else {
                System.out.println("Duplicate elements: " + duplicates);
            }

        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format. Please enter integers only.");
        }
    }
}
*/