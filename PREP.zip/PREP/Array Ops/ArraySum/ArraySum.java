import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class ArraySum {

    public static void main(String[] args) {
        try {
            int[] numbers = readArrayFromUser();
            int sum = calculateSum(numbers);
            System.out.println("Sum of array elements: " + sum);
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format. Please enter integers only.");
        }
    }

    private static int[] readArrayFromUser() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter the number of elements: ");
        int size = Integer.parseInt(reader.readLine());

        if (size <= 0) {
            throw new IllegalArgumentException("Array size must be greater than zero.");
        }

        int[] array = new int[size];

        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            array[i] = Integer.parseInt(reader.readLine());
        }

        return array;
    }

    private static int calculateSum(int[] array) {
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        return sum;
    }
}
