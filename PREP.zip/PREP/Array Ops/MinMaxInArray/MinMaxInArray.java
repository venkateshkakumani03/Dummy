// Sort Array & Find Smallest Integer, Largest Integer

import java.io.*;
import java.util.*;

public class MinMaxInArray {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter integers (space-separated): ");
        String[] parts = br.readLine().trim().split("\\s+");
        int[] arr = Arrays.stream(parts).mapToInt(Integer::parseInt).toArray();

        Arrays.sort(arr);
        System.out.println("Sorted: " + Arrays.toString(arr));
        System.out.println("Smallest: " + arr[0]);
        System.out.println("Largest: " + arr[arr.length - 1]);
    }
}

//Option2:
/*
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;

public class RemoveDups {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter integers (space-separated): ");
            String line = br.readLine().trim();
            
            int[] distinct = Arrays.stream(line.split("\\s+"))
                                   .mapToInt(Integer::parseInt)
                                   .distinct()
                                   .toArray();
            
            System.out.println(Arrays.toString(distinct));
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
*/