import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ArrayOperations {

    private final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private int[] array1;
    private int[] array2;

    public static void main(String[] args) {
        ArrayOperations app = new ArrayOperations();
        app.run();
    }

    public void run() {
        try {
            System.out.print("Enter size of arrays: ");
            int size = Integer.parseInt(reader.readLine());

            array1 = new int[size];
            array2 = new int[size];

            System.out.println("\nPopulate array1:");
            for (int i = 0; i < size; i++) {
                System.out.print("array1["+ i +"]: ");
                array1[i] = Integer.parseInt(reader.readLine());
            }

            accessElement();
            updateElement();
            modifyElements();
            searchElement();
            sumElements();

            System.out.println("\nPopulate array2 for addition and multiplication:");
            for (int i = 0; i < size; i++) {
                System.out.print("array2[" + i + "]: ");
                array2[i] = Integer.parseInt(reader.readLine());
            }

            addArrays();
            multiplyArrays();

        } catch (IOException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private void accessElement() throws IOException {
        System.out.print("\nEnter index to access in array1: ");
        int idx = Integer.parseInt(reader.readLine());
        if (idx >= 0 && idx < array1.length) {
            System.out.println("Element at index " + idx + " is " + array1[idx]);
        } else {
            System.out.println("Index out of bounds.");
        }
    }

    private void updateElement() throws IOException {
        System.out.print("\nEnter index to update in array1: ");
        int idx = Integer.parseInt(reader.readLine());
        if (idx >= 0 && idx < array1.length) {
            System.out.print("Enter new value: ");
            array1[idx] = Integer.parseInt(reader.readLine());
            System.out.println("Updated array1: ");
            printArray(array1);
        } else {
            System.out.println("Index out of bounds.");
        }
    }

    private void modifyElements() throws IOException {
        System.out.print("\nEnter value to add to each element of array1: ");
        int add = Integer.parseInt(reader.readLine());
        for (int i = 0; i < array1.length; i++) {
            array1[i] += add;
        }
        System.out.println("Modified array1: ");
        printArray(array1);
    }

    private void searchElement() throws IOException {
        System.out.print("\nEnter value to search in array1: ");
        int key = Integer.parseInt(reader.readLine());
        boolean found = false;
        for (int i = 0; i < array1.length; i++) {
            if (array1[i] == key) {
                System.out.println("Value " + key + " found at index " + i);
                found = true;
            }
        }
        if (!found) {
            System.out.println("Value not found in array1.");
        }
    }

    private void sumElements() {
        int sum = 0;
        for (int val : array1) {
            sum += val;
        }
        System.out.println("\nSum of all elements in array1: " + sum);
    }

    private void addArrays() {
        System.out.println("\nElement-wise addition of array1 and array2:");
        int[] result = new int[array1.length];
        for (int i = 0; i < array1.length; i++) {
            result[i] = array1[i] + array2[i];
        }
        printArray(result);
    }

    private void multiplyArrays() {
        System.out.println("\nElement-wise multiplication of array1 and array2:");
        int[] result = new int[array1.length];
        for (int i = 0; i < array1.length; i++) {
            result[i] = array1[i] * array2[i];
        }
        printArray(result);
    }

    private void printArray(int[] arr) {
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + (i < arr.length - 1 ? ", " : ""));
        }
        System.out.println("]");
    }
}


//Add and Mul Ops of 2D Array
/*
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class ArrayOperations {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            System.out.print("Enter number of rows: ");
            int rows = Integer.parseInt(reader.readLine());
            System.out.print("Enter number of columns: ");
            int cols = Integer.parseInt(reader.readLine());

            if (rows <= 0 || cols <= 0) {
                System.err.println("Array dimensions must be greater than zero.");
                return;
            }

            int[][] array1 = new int[rows][cols];
            int[][] array2 = new int[rows][cols];
            int[][] sum = new int[rows][cols];
            int[][] product = new int[rows][cols];

            System.out.println("\nPopulate array1:");
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    System.out.print("array1[" + i + "][" + j + "]: ");
                    array1[i][j] = Integer.parseInt(reader.readLine());
                }
            }

            System.out.println("\nPopulate array2:");
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    System.out.print("array2[" + i + "][" + j + "]: ");
                    array2[i][j] = Integer.parseInt(reader.readLine());
                }
            }

            System.out.println("\nElement-wise addition:");
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    sum[i][j] = array1[i][j] + array2[i][j];
                    System.out.print(sum[i][j] + "\t");
                }
                System.out.println();
            }

            System.out.println("\nElement-wise multiplication:");
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    product[i][j] = array1[i][j] * array2[i][j];
                    System.out.print(product[i][j] + "\t");
                }
                System.out.println();
            }

        } catch (IOException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
*/