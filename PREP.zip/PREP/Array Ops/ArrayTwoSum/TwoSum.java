import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

public class TwoSum {
	public static void main(String[] args) {		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter number of elements: ");
		try {
			int[] arr = new int[Integer.parseInt(reader.readLine())];
			for (int i = 0; i < arr.length; i++) {
				arr[i] = Integer.parseInt(reader.readLine());
			}
			System.out.print("Enter the target value: ");
			int target = Integer.parseInt(reader.readLine());
			Map<Integer, Integer> numMap = new HashMap<>();
			boolean found = false;
			for (int i = 0; i < arr.length; i++) {
				int complement = target - arr[i];
				if (numMap.containsKey(complement)) {
					// System.out.println(numMap.get(complement)+" , "+ i); // to get indices
					System.out.println(complement+" , "+ arr[i]);
					found = true;
					break;
				}
				numMap.put(arr[i], i);
			}
			if (!found) {
				System.out.println("No Two sum solution found.");
			}
		} catch (IOException e) {
			System.err.println("Error: " + e.getMessage());
		}
	}
}