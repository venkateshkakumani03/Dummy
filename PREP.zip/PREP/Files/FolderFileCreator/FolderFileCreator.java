import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FolderFileCreator {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter the number of folders to create: ");
        int folderCount = Integer.parseInt(reader.readLine());

        System.out.print("Enter the number of text files per folder: ");
        int fileCount = Integer.parseInt(reader.readLine());

        System.out.print("Enter text to write in files: ");
        String input = reader.readLine();

        for (int i = 1; i <= folderCount; i++) {
            String folderName = "Folder_" + i;
            Files.createDirectories(Paths.get(folderName));

            for (int j = 1; j <= fileCount; j++) {
                String fileName = "file_" + j + ".txt";
                try (FileWriter writer = new FileWriter(folderName + "/" + fileName)) {
                    writer.write(input + "\nHello, Good morning! This is " + fileName);
                }
            }
        }

        System.out.println("Folders and files created successfully.");
    }
}