//Option-1
/*
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

public class CSVFileCreator {
	public static void main(String[] args) {
		Map<Integer, String> data = new HashMap<>();
	        data.put(1, "Sail Point");
        	data.put(2, "Cyber Ark");
	        data.put(3, "Okta");
	        data.put(4, "Ping Federate");
	        data.put(5, "Silver Fort");
	        data.put(6, "Forge Rock");
	        data.put(7, "Proof Point");

        	String filename = "Example.csv";

	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
        	    writer.write("Serial NO.,Heading");
	            writer.newLine();

        	    for (Map.Entry<Integer, String> entry : data.entrySet()) {
                	writer.write(entry.getKey() + "," + entry.getValue());
	                writer.newLine();
        	    }
	            System.out.println("CSV file is created.");
        	}catch (IOException e) {
	            System.out.println("Error in input");
        	}
	}
}*/


//Option-2

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

public class CSVFileCreator {
    public static void main(String[] args) {
        Map<Integer, String> data = new HashMap<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter data in the format <Key>=<Value> (type 'exit' to finish):");

        try {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equalsIgnoreCase("exit")) {
                    break;
                }

                if (line.trim().isEmpty()) continue;

                String[] parts = line.split("=", 2);
                if (parts.length == 2) {
                    try {
                        int key = Integer.parseInt(parts[0].trim());
                        String value = parts[1].trim();
                        data.put(key, value);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid number format for key: " + parts[0]);
                    }
                } else {
                    System.out.println("Invalid input format. Use <Key>=<Value>");
                }
            }
	    System.out.print("Enter Filename: "); 
            String filename = reader.readLine()+".csv";
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                writer.write("Serial NO.,Heading");
                writer.newLine();

                for (Map.Entry<Integer, String> entry : data.entrySet()) {
                    writer.write(entry.getKey() + "," + entry.getValue());
                    writer.newLine();
                }

                System.out.println("CSV file '" + filename + "' has been created.");
            } catch (IOException e) {
                System.out.println("Error writing to file: " + e.getMessage());
            }

        } catch (IOException e) {
            System.out.println("Error reading input: " + e.getMessage());
        }
    }
}

