import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Map;
import java.util.LinkedHashMap;

public class ProductsOfPrime {
	public static void main(String[] args) {
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
			System.out.print("Enter a number: ");
			int num = Integer.parseInt(reader.readLine());
			int n = num;
			Map<Integer, Integer> factorM = new LinkedHashMap<>();
			for (int i = 2; i <= n; i++) {
				boolean isPrime = true;
				for (int j = 2; j <= Math.sqrt(i); j++) {
					if (i % j == 0) {
						isPrime = false;
						break;
					}
				}
				while (isPrime && n % i == 0) {
					factorM.put(i, factorM.getOrDefault(i, 0) + 1);
					n /= i;
				}
			}
			System.out.print("Prime factors of " + num + " is: ");
			boolean first = true;
			for (Map.Entry<Integer, Integer> entry : factorM.entrySet()) {
				if (!first) System.out.print(" * ");
				System.out.print(entry.getKey() + "^" + entry.getValue());
				first = false;
			}
		} catch(IOException e) {
			System.err.println("Error while reading.");
		}
	}
}