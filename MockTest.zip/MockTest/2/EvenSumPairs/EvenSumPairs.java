public class EvenSumPairs {
    public static void printEvenSumPairs(int[] array1, int[] array2) {
        // Your code here
	for(int i = 0; i < array1.length; i++) {
		for(int j = 0; j < array1.length; j++) {
			int temp = array1[i] + array2[j];
//			if(temp == 6) {
			if(temp % 2 ==0) {
				System.out.println("("+array1[i]+","+array2[j]+")");
			}
		}
	}
    }
    public static void main(String[] args) {
        int[] array1 = {1, 2, 3};
        int[] array2 = {4, 5, 6};
        printEvenSumPairs(array1, array2);
    }
}