import java.util.*;

public class PrimeInvertedPyramid {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Give a number: ");
        int input = sc.nextInt();

        List<Integer> primes = new ArrayList<>();
        for (int i = 2; i <= input; i++)
            if (isPrime(i)) primes.add(i);

        int idx = primes.size() - 1;
        int rows = 1, used = 0;
        while (used + rows <= primes.size()) {
            used += rows++;
        }

        for (int i = rows - 1; i >= 1; i--) {
            System.out.print(" ".repeat((rows - i) * 3));
            for (int j = 0; j < i && idx >= 0; j++)
                System.out.printf("%3d ", primes.get(idx--));
            System.out.println();
        }

        while (idx >= 0)
            System.out.printf("%3d ", primes.get(idx--));
    }

    static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i*i <= n; i++)
            if (n % i == 0) return false;
        return true;
    }
}