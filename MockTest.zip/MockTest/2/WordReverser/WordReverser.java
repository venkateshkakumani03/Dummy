public class WordReverser {
	public static void main(String[] args) {
		String input = "Hello World!";
		String[] arr = input.split(" ");
		for(int i = 0; i < arr.length; i++) {
			String temp = new StringBuilder(arr[i]).reverse().toString();
			System.out.print(temp+" ");
		}
	}
}
		