import java.util.Random;
import java.util.Arrays;
public class ArrayRotation{
	public static void main(String[] args) {
		int[] array = new int[10];
		Random rand = new Random();

		for(int i = 0; i < array.length; i++) {
			array[i] = rand.nextInt(100);
		}
		System.out.println("Array elements: " + Arrays.toString(array));

		int[] rotatedArray = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			int newIndex = (i + 3) % array.length;
			rotatedArray[newIndex] = array[i];
		}

		for(int i = 0; i < 3; i++) {
			rotatedArray[i] = 0;
		}
		System.out.println(Arrays.toString(rotatedArray));
	}
}