import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

public class RemoveDuplicates {

    public static void main(String[] args) {
        List<String> list = readStringsFromUser();
        List<String> uniqueList = removeDuplicates(list);
        printList(uniqueList);
    }

    private static List<String> readStringsFromUser() {
        List<String> list = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter the number of elements: ");
            int size = Integer.parseInt(reader.readLine().trim());

            if (size <= 0) {
                System.err.println("Invalid input: The number of elements must be greater than zero.");
                return list;
            }

            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                String input = reader.readLine().trim();
                if (input.isEmpty()) {
                    System.err.println("Invalid input: Element cannot be empty.");
                    continue;
                }
                list.add(input);
            }

        } catch (IOException e) {
            System.err.println("Input error: Unable to read from the console.");
        } catch (NumberFormatException e) {
            System.err.println("Format error: Please enter a valid integer for the number of elements.");
        }

        return list;
    }

    private static List<String> removeDuplicates(List<String> list) {
        return new ArrayList<>(new LinkedHashSet<>(list));
    }

    private static void printList(List<String> list) {
        if (list.isEmpty()) {
            System.out.println("No elements to display.");
        } else {
            System.out.println("Unique list: " + list);
        }
    }
}
