class ChildThread extends Thread {
    @Override
    public void run() {
        try {
            for (int i = 0; i < 5; i++) {

                if (i == 1) {
                    System.out.println("Hi, Good Morning!");
                    System.out.println("Child Thread sleeping for 10 seconds...");
                    Thread.sleep(10000);
                }
            }
        } catch (InterruptedException e) {
            System.out.println("Child Thread interrupted! Exception: " + e);
        }
    }
}

public class MainThread {
    public static void main(String[] args) {
        ChildThread child = new ChildThread();
        child.start();

        try {
            Thread.sleep(3000);
            child.interrupt();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }

        System.out.println("End of main method");
    }
}

