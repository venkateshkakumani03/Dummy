/*

+1 NXX-NXX-XXXX
N=digits 2–9, X=digits 0–9
+1 is the country code that includes the US, there are 17 other countries, e.g., Canada, Caribbean Islands.
The first 3 digits, NXX, is the area code which corresponds to a geographic area like a city. Or it could designate a service, like toll free (aka, free phone).
The next 3 digits are called the central office code. NXX-NXX designates a specific service provider and switch for routing purposes.
The full 10 digits are called a line number, which are assigned to users.

It is comprised of 11 digits. The first digit is your country code, which tells you that you’re in America. 
Then your 3 digit area code, which is usually based off of counties. (e.g 248 specifies you’re in Oakland County, Michigan). 
Then a 7 digit telephone number which is further comprised of an exchange code and a carrier code. 
The first 3 digits are an exchange code, which tells your phone what city your phone number is located in. 
(Example: 248.821 specifies you’re in Pontiac). Then the last 4 digits are a carrier code, which tells your phone to which towers to route the call.
This is how a phone number is deconstructed. (Example: 248.821.8848 specifies that you’re in Pontiac, Oakland County, Michigan, United States and your phone plan is with AT&T)

https://callhippo.com/blog/general/us-phone-number-format-with-country-code#:~:text=United%20States%20Phone%20Number%20Example,-What%20is%20the&text=In%20the%20USA%2C%20country%20code,code%20to%20a%20phone%20number.
*/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class USPhoneNumberValidator {

    public static void main(String[] args) {
        String input = getUserInput();
        boolean isValid = validatePhoneNumber(input);
        printResult(isValid);
    }

    private static String getUserInput() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a US phone number to validate: ");
            return reader.readLine().trim();
        } catch (IOException e) {
            System.out.println("Error reading input: " + e.getMessage());
            return "";
        }
    }

    private static boolean validatePhoneNumber(String phoneNumber) {
        String cleanedNumber = removeNonDigitCharacters(phoneNumber);

        if (!isLengthValid(cleanedNumber)) {
            return false;
        }

        return matchesValidPattern(cleanedNumber);
    }

    private static String removeNonDigitCharacters(String phoneNumber) {
        return phoneNumber.replaceAll("\\D", "");
    }

    private static boolean isLengthValid(String cleanedNumber) {
        if (cleanedNumber.length() == 10) return true;
        return cleanedNumber.length() == 11 && cleanedNumber.startsWith("1");
    }

    private static boolean matchesValidPattern(String cleanedNumber) {
        // Remove leading 1 if it's 11-digit
        if (cleanedNumber.length() == 11 && cleanedNumber.startsWith("1")) {
            cleanedNumber = cleanedNumber.substring(1);
        }

        // NXX-NXX-XXXX, N = 2-9, X = 0-9
        String pattern = "^[2-9][0-9]{2}[2-9][0-9]{2}[0-9]{4}$";
        return Pattern.matches(pattern, cleanedNumber);
    }

    private static void printResult(boolean isValid) {
        if (isValid) {
            System.out.println("Phone number is valid.");
        } else {
            System.out.println("Invalid phone number.");
        }
    }
}


//Option2 Simple way

/*
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.regex.Pattern;

public class USPhoneNumberValidator {

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter a US phone number to validate: ");
            String input = reader.readLine().trim();

            String cleanedNumber = input.replaceAll("\\D", "");

            boolean isValid = false;
            if (cleanedNumber.length() == 10 || (cleanedNumber.length() == 11 && cleanedNumber.startsWith("1"))) {

                if (cleanedNumber.length() == 11) {
                    cleanedNumber = cleanedNumber.substring(1);
                }

                String pattern = "^[2-9][0-9]{2}[2-9][0-9]{2}[0-9]{4}$";
                isValid = Pattern.matches(pattern, cleanedNumber);
            }

            System.out.println(isValid ? "Phone number is valid." : "Invalid phone number.");

        } catch (IOException e) {
            System.out.println("Error reading input: " + e.getMessage());
        }
    }
}
*/