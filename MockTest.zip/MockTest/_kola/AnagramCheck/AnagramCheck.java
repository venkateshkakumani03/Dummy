import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class AnagramCheck {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Enter first string: ");
            String str1 = reader.readLine().replaceAll("\\s", "").toLowerCase();
            System.out.print("Enter second string: ");
            String str2 = reader.readLine().replaceAll("\\s", "").toLowerCase();

            if (isAnagram(str1, str2)) {
                System.out.println("Anagrams");
            } else {
                System.out.println("Not anagrams");
            }
        } catch (IOException e) {
            System.out.println("Error reading input: " + e.getMessage());
        }
    }

    public static boolean isAnagram(String str1, String str2) {
        if (str1.length() != str2.length()) return false;

        char[] a = str1.toCharArray();
        char[] b = str2.toCharArray();
        Arrays.sort(a);
        Arrays.sort(b);

        return Arrays.equals(a, b);
    }
}