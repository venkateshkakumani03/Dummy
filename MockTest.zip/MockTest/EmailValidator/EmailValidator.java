import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class EmailValidator {
	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter an E-mail: ");
		try{
		    String email = reader.readLine();
		    String reg_set = "^[A-Za-z]{1,9}+.[A-Za-z]{1,9}+@[A-Za-z]+.[A-Za-z]{1,3}+$";

		    Pattern pattern = Pattern.compile(reg_set);
		    Matcher matcher = pattern.matcher(email);
		    
		    if(matcher.matches()) {
		        System.out.println(email+" is Valid.");
		    }else{
		        System.out.println(email+" is not Valid.");
		    }
		}catch(IOException e) {
		    System.out.println("I/O Error.");
		}
	}
}