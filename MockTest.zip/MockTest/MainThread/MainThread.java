public class MainThread {
	public static void main(String[] args) {
		ChildThread child = new ChildThread();
		child.start();
	}
}

class ChildThread extends Thread {
	Thread t = new Thread();
	public void run() {
		try{
			for(int i = 0; i < 5; i++){
				System.out.println("Hi!, Good Morning.");
				t.sleep(5000);
			}
		} catch(InterruptedException e) {
			System.out.println("Interrupted Exception");
		}
		System.out.println("End of main method.");
	} 
}