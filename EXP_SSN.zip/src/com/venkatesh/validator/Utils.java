package com.venkatesh.validator;

import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Utility class using Apache Commons for common tasks.
 * 
 * @author Venkatesh Kakumani
 */
public class Utils {

    public static boolean isNullOrEmpty(String input) {
        return StringUtils.isEmpty(input);
    }

    public static boolean promptYesNo(String question) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print(question + " (yes/no): ");
        String response = reader.readLine().trim().toLowerCase();
        return response.equals("yes") || response.equals("y");
    }

    public static int selectMode() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Choose input mode:");
        System.out.println("1. Manual");
        System.out.println("2. Batch CSV");
        System.out.println("3. GUI");
        System.out.print("Enter your choice (1-3): ");
        return Integer.parseInt(reader.readLine());
    }
}
