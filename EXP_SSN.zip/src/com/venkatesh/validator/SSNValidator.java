package com.venkatesh.validator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Validates SSNs manually and interacts with the user.
 * Thread-safe and interactive.
 *
 * @author Venkatesh Kakumani
 * @version 2.0
 * @since 2025-07-05
 */
public class SSNValidator {
    private static final Logger logger = LogManager.getLogger(SSNValidator.class);

    public static void runManual() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            boolean runAgain;
            do {
                System.out.print("Enter SSN (format XXX-XX-XXXX): ");
                String input = reader.readLine();
                if (!Utils.isNullOrEmpty(input)) {
                    boolean result = validateSSN(input);
                    logger.info("SSN [{}] validation result: {}", input, result);
                    System.out.println(result ? "SSN is valid" : "SSN is invalid");
                } else {
                    logger.warn("User entered a null or empty SSN string.");
                }
                runAgain = Utils.promptYesNo("Do you want to validate another SSN?");
            } while (runAgain);
        } catch (IOException io) {
            logger.error("I/O error in manual SSN validation: {}", io.getMessage());
        }
    }

    /**
     * Validates a single SSN.
     *
     * @param ssn input SSN string
     * @return true if valid, false otherwise
     */
    public static boolean validateSSN(String ssn) {
        if (!ssn.matches("^\\d{3}-\\d{2}-\\d{4}$")) return false;
        if (ssn.equals("078-05-1120")) return false;

        String[] parts = ssn.split("-");
        int area = Integer.parseInt(parts[0]);
        int group = Integer.parseInt(parts[1]);
        int serial = Integer.parseInt(parts[2]);

        return area > 0 && area != 666 && area < 900 && group > 0 && serial > 0;
    }
}
