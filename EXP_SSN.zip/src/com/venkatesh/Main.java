package com.venkatesh;

import com.venkatesh.validator.SSNValidator;
import com.venkatesh.io.CSVProcessor;
import com.venkatesh.gui.SSNValidatorGUI;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Entry point for SSN Validation application.
 * Presents user choice: manual, batch, or GUI.
 * 
 * @author Venkatesh Kakumani
 * @version 2.0
 * @since 2025-07-05
 */
public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        try {
            setupLogDirectory();
            int choice = Utils.selectMode();
            switch (choice) {
                case 1 -> SSNValidator.runManual();
                case 2 -> CSVProcessor.runBatch();
                case 3 -> SSNValidatorGUI.launch();
                default -> logger.error("Invalid selection: {}", choice);
            }
        } catch (IOException e) {
            logger.error("I/O error during setup: {}", e.getMessage());
        }
    }

    private static void setupLogDirectory() throws IOException {
        Path logDir = Paths.get("logs");
        if (Files.notExists(logDir)) {
            Files.createDirectories(logDir);
            logger.info("Created logs directory at {}", logDir.toAbsolutePath());
        }
    }
}
