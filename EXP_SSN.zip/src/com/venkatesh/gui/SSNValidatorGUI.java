package com.venkatesh.gui;

import com.venkatesh.validator.SSNValidator;
import org.apache.commons.lang3.StringUtils;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * JavaFX GUI for SSN Validation.
 *
 * @author Venkatesh Kakumani
 */
public class SSNValidatorGUI extends Application {

    private static final Logger logger = LogManager.getLogger(SSNValidatorGUI.class);

    public static void launch() {
        Application.launch();
    }

    @Override
    public void start(Stage primaryStage) {
        Label label = new Label("Enter SSN (XXX-XX-XXXX):");
        TextField ssnField = new TextField();
        Button validateButton = new Button("Validate");
        Label resultLabel = new Label();

        validateButton.setOnAction(e -> {
            String ssn = ssnField.getText();
            if (StringUtils.isEmpty(ssn)) {
                resultLabel.setText("Please enter an SSN.");
                logger.warn("Empty input in GUI.");
                return;
            }
            boolean isValid = SSNValidator.validateSSN(ssn);
            resultLabel.setText(isValid ? "SSN is valid." : "Invalid SSN.");
            logger.info("GUI SSN [{}] -> Valid: {}", ssn, isValid);
        });

        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, ssnField, validateButton, resultLabel);

        Scene scene = new Scene(layout, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("SSN Validator - JavaFX");
        primaryStage.show();
    }
}
