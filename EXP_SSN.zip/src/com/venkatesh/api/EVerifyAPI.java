package com.venkatesh.api;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Simulated E-Verify API connector class for future integration.
 *
 * @author Venkatesh Kakumani
 */
public class EVerifyAPI {
    private static final Logger logger = LogManager.getLogger(EVerifyAPI.class);

    public boolean verifySSN(String ssn, String name) {
        logger.debug("Mock verifying SSN [{}] for name [{}]", ssn, name);
        return ssn.startsWith("1") || ssn.startsWith("2");
    }
}
