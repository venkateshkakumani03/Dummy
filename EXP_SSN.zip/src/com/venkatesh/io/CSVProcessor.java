package com.venkatesh.io;

import com.venkatesh.validator.SSNValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Processes batch SSN validation via CSV input.
 * Thread-safe, duplicate-detection capable.
 *
 * @author Venkatesh Kakumani
 * @version 1.0
 * @since 2025-07-05
 */
public class CSVProcessor {
    private static final Logger logger = LogManager.getLogger(CSVProcessor.class);

    public static void runBatch() {
        System.out.print("Enter CSV file path: ");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            String filePath = reader.readLine();
            File file = new File(filePath);
            if (!file.exists()) {
                logger.warn("File does not exist: {}", filePath);
                return;
            }

            ExecutorService executor = Executors.newFixedThreadPool(4);
            ConcurrentHashMap<String, Integer> ssnMap = new ConcurrentHashMap<>();

            try (BufferedReader fileReader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = fileReader.readLine()) != null) {
                    final String ssn = line.trim();
                    executor.submit(() -> {
                        boolean valid = SSNValidator.validateSSN(ssn);
                        ssnMap.merge(ssn, 1, Integer::sum);
                        logger.info("Batch SSN [{}] -> Valid: {}", ssn, valid);
                    });
                }
            }

            executor.shutdown();
            while (!executor.isTerminated()) Thread.sleep(100);

            ssnMap.forEach((key, value) -> {
                if (value > 1) {
                    logger.warn("Duplicate SSN Detected: {} ({} times)", key, value);
                }
            });

        } catch (IOException io) {
            logger.error("Error reading CSV: {}", io.getMessage());
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            logger.error("Batch thread interrupted: {}", ie.getMessage());
        }
    }
}
