package com.venkatesh.validator;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SSNValidator class.
 *
 * @author Venkatesh Kakumani
 */
public class SSNValidatorTest {

    @Test
    void testValidSSN() {
        assertTrue(SSNValidator.validateSSN("123-45-6789"));
    }

    @Test
    void testInvalidSSNFormat() {
        assertFalse(SSNValidator.validateSSN("123456789"));
    }

    @Test
    void testKnownFakeSSN() {
        assertFalse(SSNValidator.validateSSN("078-05-1120"));
    }

    @Test
    void testInvalidArea() {
        assertFalse(SSNValidator.validateSSN("000-12-3456"));
    }
}
